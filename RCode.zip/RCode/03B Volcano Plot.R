################################################################################
########SPLIT UP BASED ON PATHWAY############################################
################################################################################

pathway_colors = c("Lipid" = "cyan", "Peptide" = "red", "Xenobiotics" = "green", "Unknown" = "orange")
#####CO
CO_all_volcano<-main_results[["dtscaled_CO_exp_met"]]
non_sig_CO<-subset(CO_all_volcano, pfdr > 0.2)


CO_LC_volcano<-main_results[["CO_exp_LC_met"]][main_results[["CO_exp_LC_met"]]$COMP_ID %in% main_sig_LC_results[["CO_exp_LC_met"]]$COMP_ID, ]
CO_LC_volcano<-merge(CO_LC_volcano, biochem.blood, by = "COMP_ID")

CO_volcano<-
  ggplot(data = CO_all_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = sig_CO_met, aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_CO, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  geom_point(data = CO_LC_volcano, aes(x = Est, y = -log(pfdr), colour = SUPER_PATHWAY))+
  scale_color_manual(values = pathway_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = "CO")+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())

#####NO2
NO2_all_volcano<-main_results[["dtscaled_NO2_exp_met"]]
non_sig_NO2<-subset(NO2_all_volcano, pfdr > 0.2)

#Pull the significant metabolites from the AP and LC models
NO2_LC_volcano<-main_results[["dtscaled_NO2_exp_met"]][main_results[["dtscaled_NO2_exp_met"]]$COMP_ID %in% main_sig_LC_results[["NO2_exp_LC_met"]]$COMP_ID, ]
NO2_LC_volcano<-merge(NO2_LC_volcano, biochem.blood, by = "COMP_ID")

NO2_volcano<-
  ggplot(data = NO2_LC_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = main_results[["dtscaled_NO2_exp_met"]], aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_NO2, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  geom_point(data = NO2_LC_volcano, aes(x = Est, y = -log(pfdr), colour = SUPER_PATHWAY))+
  scale_color_manual(values = pathway_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = expression("NO"[2]))+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())


#####O3
O3_all_volcano<-main_results[["dtscaled_O3_exp_met"]]
non_sig_O3<-subset(O3_all_volcano, pfdr > 0.2)

#Pull the significant metabolites from the AP and LC models
#O3_LC_volcano<-main_results[["dtscaled_O3_exp_met"]][main_results[["dtscaled_O3_exp_met"]]$COMP_ID %in% main_sig_LC_results[["O3_exp_LC_met"]]$COMP_ID, ]
#O3_LC_volcano<-merge(O3_LC_volcano, biochem.blood, by = "COMP_ID")

O3_volcano<-
  ggplot(data = O3_all_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = main_results[["dtscaled_O3_exp_met"]], aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_O3, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  #geom_point(data = NO2_LC_volcano, aes(x = Est, y = -log(pfdr), colour = COMP_ID))+
  #scale_color_manual(values = metabolite_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = expression("O"[3]))+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())

#####PM10
PM10_all_volcano<-main_results[["dtscaled_PM10_exp_met"]]
non_sig_PM10<-subset(PM10_all_volcano, pfdr > 0.2)

#Pull the significant metabolites from the AP and LC models
PM10_LC_volcano<-main_results[["dtscaled_PM10_exp_met"]][main_results[["dtscaled_PM10_exp_met"]]$COMP_ID %in% main_sig_LC_results[["PM10_exp_LC_met"]]$COMP_ID, ]
PM10_LC_volcano<-merge(PM10_LC_volcano, biochem.blood, by = "COMP_ID")

PM10_volcano<-
  ggplot(data = PM10_LC_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = main_results[["dtscaled_PM10_exp_met"]], aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_PM10, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  geom_point(data = PM10_LC_volcano, aes(x = Est, y = -log(pfdr), colour = SUPER_PATHWAY))+
  scale_color_manual(values = pathway_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = expression("PM"[10]))+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())

PM25_all_volcano<-main_results[["dtscaled_PM25_exp_met"]]
non_sig_PM25<-subset(PM25_all_volcano, pfdr > 0.2)

#Pull the significant metabolites from the AP and LC models
PM25_LC_volcano<-main_results[["dtscaled_PM25_exp_met"]][main_results[["dtscaled_PM25_exp_met"]]$COMP_ID %in% main_sig_LC_results[["PM25_exp_LC_met"]]$COMP_ID, ]
PM25_LC_volcano<-merge(PM25_LC_volcano, biochem.blood, by = "COMP_ID")

PM25_volcano<-
  ggplot(data = PM25_LC_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = main_results[["dtscaled_PM25_exp_met"]], aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_PM25, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  geom_point(data = PM25_LC_volcano, aes(x = Est, y = -log(pfdr), colour = SUPER_PATHWAY))+
  scale_color_manual(values = pathway_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = expression("PM"[2.5]))+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())

#####SO2
SO2_all_volcano<-main_results[["dtscaled_SO2_exp_met"]]
non_sig_SO2<-subset(SO2_all_volcano, pfdr > 0.2)

#Pull the significant metabolites from the AP and LC models
#SO2_LC_volcano<-main_results[["dtscaled_SO2_exp_met"]][main_results[["dtscaled_SO2_exp_met"]]$COMP_ID %in% main_sig_LC_results[["SO2_exp_LC_met"]]$COMP_ID, ]
#SO2_LC_volcano<-merge(SO2_LC_volcano, biochem.blood, by = "COMP_ID")

SO2_volcano<-
  ggplot(data = SO2_all_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = main_results[["dtscaled_SO2_exp_met"]], aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_SO2, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  #geom_point(data = NO2_LC_volcano, aes(x = Est, y = -log(pfdr), colour = COMP_ID))+
  #scale_color_manual(values = metabolite_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = expression("SO"[2]))+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())











################################################################################
########SPLIT UP BASED ON METABOLITE############################################
################################################################################

metabolite_colors = c("X61771" = "cyan", "X48442" = "red", "X32412" = "green", 
                      "X2730" = "orange", "X44872" = "darkorchid2", "X31536" = "deeppink",
                      "X52925" = "deepskyblue1", "X49531" = "coral3")
#####CO
CO_all_volcano<-main_results[["dtscaled_CO_exp_met"]]
non_sig_CO<-subset(CO_all_volcano, pfdr > 0.2)


CO_LC_volcano<-main_results[["CO_exp_LC_met"]][main_results[["CO_exp_LC_met"]]$COMP_ID %in% main_sig_LC_results[["CO_exp_LC_met"]]$COMP_ID, ]
CO_LC_volcano<-merge(CO_LC_volcano, biochem.blood, by = "COMP_ID")

CO_volcano<-
  ggplot(data = CO_all_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = sig_CO_met, aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_CO, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  geom_point(data = CO_LC_volcano, aes(x = Est, y = -log(pfdr), colour = COMP_ID))+
  scale_color_manual(values = metabolite_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = "CO")+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())

#####NO2
NO2_all_volcano<-main_results[["dtscaled_NO2_exp_met"]]
non_sig_NO2<-subset(NO2_all_volcano, pfdr > 0.2)

#Pull the significant metabolites from the AP and LC models
NO2_LC_volcano<-main_results[["dtscaled_NO2_exp_met"]][main_results[["dtscaled_NO2_exp_met"]]$COMP_ID %in% main_sig_LC_results[["NO2_exp_LC_met"]]$COMP_ID, ]
NO2_LC_volcano<-merge(NO2_LC_volcano, biochem.blood, by = "COMP_ID")

NO2_volcano<-
  ggplot(data = NO2_LC_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = main_results[["dtscaled_NO2_exp_met"]], aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_NO2, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  geom_point(data = NO2_LC_volcano, aes(x = Est, y = -log(pfdr), colour = COMP_ID))+
  scale_color_manual(values = metabolite_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = expression("NO"[2]))+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())


#####O3
O3_all_volcano<-main_results[["dtscaled_O3_exp_met"]]
non_sig_O3<-subset(O3_all_volcano, pfdr > 0.2)

#Pull the significant metabolites from the AP and LC models
#O3_LC_volcano<-main_results[["dtscaled_O3_exp_met"]][main_results[["dtscaled_O3_exp_met"]]$COMP_ID %in% main_sig_LC_results[["O3_exp_LC_met"]]$COMP_ID, ]
#O3_LC_volcano<-merge(O3_LC_volcano, biochem.blood, by = "COMP_ID")

O3_volcano<-
  ggplot(data = O3_all_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = main_results[["dtscaled_O3_exp_met"]], aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_O3, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  #geom_point(data = NO2_LC_volcano, aes(x = Est, y = -log(pfdr), colour = COMP_ID))+
  #scale_color_manual(values = metabolite_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = expression("O"[3]))+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())

#####PM10
PM10_all_volcano<-main_results[["dtscaled_PM10_exp_met"]]
non_sig_PM10<-subset(PM10_all_volcano, pfdr > 0.2)

#Pull the significant metabolites from the AP and LC models
PM10_LC_volcano<-main_results[["dtscaled_PM10_exp_met"]][main_results[["dtscaled_PM10_exp_met"]]$COMP_ID %in% main_sig_LC_results[["PM10_exp_LC_met"]]$COMP_ID, ]
PM10_LC_volcano<-merge(PM10_LC_volcano, biochem.blood, by = "COMP_ID")

PM10_volcano<-
  ggplot(data = PM10_LC_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = main_results[["dtscaled_PM10_exp_met"]], aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_PM10, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  geom_point(data = PM10_LC_volcano, aes(x = Est, y = -log(pfdr), colour = COMP_ID))+
  scale_color_manual(values = metabolite_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = expression("PM"[10]))+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())

PM25_all_volcano<-main_results[["dtscaled_PM25_exp_met"]]
non_sig_PM25<-subset(PM25_all_volcano, pfdr > 0.2)

#Pull the significant metabolites from the AP and LC models
PM25_LC_volcano<-main_results[["dtscaled_PM25_exp_met"]][main_results[["dtscaled_PM25_exp_met"]]$COMP_ID %in% main_sig_LC_results[["PM25_exp_LC_met"]]$COMP_ID, ]
PM25_LC_volcano<-merge(PM25_LC_volcano, biochem.blood, by = "COMP_ID")

PM25_volcano<-
  ggplot(data = PM25_LC_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = main_results[["dtscaled_PM25_exp_met"]], aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_PM25, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  geom_point(data = PM25_LC_volcano, aes(x = Est, y = -log(pfdr), colour = COMP_ID))+
  scale_color_manual(values = metabolite_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = expression("PM"[2.5]))+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())

#####SO2
SO2_all_volcano<-main_results[["dtscaled_SO2_exp_met"]]
non_sig_SO2<-subset(SO2_all_volcano, pfdr > 0.2)

#Pull the significant metabolites from the AP and LC models
#SO2_LC_volcano<-main_results[["dtscaled_SO2_exp_met"]][main_results[["dtscaled_SO2_exp_met"]]$COMP_ID %in% main_sig_LC_results[["SO2_exp_LC_met"]]$COMP_ID, ]
#SO2_LC_volcano<-merge(SO2_LC_volcano, biochem.blood, by = "COMP_ID")

SO2_volcano<-
  ggplot(data = SO2_all_volcano, aes(x = Est, y = -log(pfdr))) +
  geom_point(data = main_results[["dtscaled_SO2_exp_met"]], aes(x = Est, y = -log(pfdr)), colour = "black")+
  geom_point(data = non_sig_SO2, aes(x = Est, y = -log(pfdr)), colour = "grey")+
  #geom_point(data = NO2_LC_volcano, aes(x = Est, y = -log(pfdr), colour = COMP_ID))+
  #scale_color_manual(values = metabolite_colors)+
  geom_hline(yintercept= -log(0.2), linetype = "dashed",  col = c("darkred"), linewidth = 0.5)+
  labs(title = expression("SO"[2]))+
  xlab("Effect Estimate") +
  ylab("-log(FDR)")+
  theme(
    legend.position = "none",
    axis.title.y = element_blank(), 
    axis.title.x = element_blank())

