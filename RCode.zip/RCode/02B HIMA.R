library(HIMA)

###Remove Missing Data
BMI_rm<-dtscaled
#First remove missing BMI participants
BMI_rm$missing<-ifelse(is.na(BMI_rm$BMI), 1, 0)
table(BMI_rm$missing)
BMI_missing<-BMI_rm$ID[BMI_rm$missing==1]
BMI_missingmatchID<-BMI_rm$MATCHID.x[BMI_rm$ID %in% BMI_missing]
BMI_rm<-BMI_rm[!BMI_rm$MATCHID.x %in% BMI_missingmatchID, ]
#Now remove missing FV_UPDATEDly
sum(is.na(BMI_rm$FV_UPDATED))
BMI_rm$missing<-ifelse(is.na(BMI_rm$FV_UPDATED), 1, 0)
table(BMI_rm$missing)
BMI_missing<-BMI_rm$ID[BMI_rm$missing==1]
BMI_missingmatchID<-BMI_rm$MATCHID.x[BMI_rm$ID %in% BMI_missing]
BMI_rm<-BMI_rm[!BMI_rm$MATCHID.x %in% BMI_missingmatchID, ]
#Final obs. count should be 1303

BMI_rm$FV_UPDATED<-as.numeric(BMI_rm$FV_UPDATED)

##Find the missing race person to remove
m_ind <- which(BMI_rm$RACE == "Missing")
BMI_rm <- BMI_rm[-m_ind, ]
BMI_rm$RACE<-droplevels(BMI_rm$RACE)
##1200 participants now in the dataset

##Make all the covariates into the numeric and categorical variables dummy
#sex
BMI_rm$SEX1 <- as.integer(as.factor(BMI_rm$SEX))-1
#race
BMI_rm$RACE1<-as.integer(as.factor(BMI_rm$RACE))-1
#education
table(BMI_rm$EDUCGRP)
BMI_rm$uHS<-ifelse(BMI_rm$EDUCGRP == "Less than HS", 1, 0)
BMI_rm$HS<-ifelse(BMI_rm$EDUCGRP == "HS Graduate", 1, 0)
BMI_rm$someCol<-ifelse(BMI_rm$EDUCGRP == "Some College/Tech School/2-year Degree", 1, 0)
BMI_rm$Col<-ifelse(BMI_rm$EDUCGRP == "College Graduate", 1, 0)
BMI_rm$beCol<-ifelse(BMI_rm$EDUCGRP == "Graduate School", 1, 0)
BMI_rm$missedu<-ifelse(BMI_rm$EDUCGRP == "Missing", 1, 0)
#MVUSE
table(BMI_rm$MVUSE)
BMI_rm$recentMVUSE<-ifelse(BMI_rm$MVUSE == "Recently", 1, 0)
BMI_rm$somewhatrecentMVUSE<-ifelse(BMI_rm$MVUSE == "Somewhat Recently", 1, 0)
BMI_rm$rarelyMVUSE<-ifelse(BMI_rm$MVUSE == "Rarely/Never", 1, 0)
BMI_rm$missMVUSE<-ifelse(BMI_rm$MVUSE == "Missing", 1, 0)
#ALC
table(BMI_rm$ALC)
BMI_rm$noneALC<-ifelse(BMI_rm$ALC == "None", 1, 0)
BMI_rm$under1ALC<-ifelse(BMI_rm$ALC == "<1 per day", 1, 0)
BMI_rm$over1ALC<-ifelse(BMI_rm$ALC == "1+ per day", 1, 0)
BMI_rm$missALC<-ifelse(BMI_rm$ALC == "Missing", 1, 0)
#Smokegroup1
table(BMI_rm$Smokegroup1)
BMI_rm$neversmoker<-ifelse(BMI_rm$Smokegroup1 == "Never", 1, 0)
BMI_rm$currentsmoker<-ifelse(BMI_rm$Smokegroup1 == "Current", 1, 0)
BMI_rm$formersmoker<-ifelse(BMI_rm$Smokegroup1 == "Former", 1, 0)
#PASSIVESMOKER
table(BMI_rm$PASSIVESMOKER)
BMI_rm$yespassive<-ifelse(BMI_rm$PASSIVESMOKER == "Yes", 1, 0)
BMI_rm$nopassive<-ifelse(BMI_rm$PASSIVESMOKER == "No", 1, 0)
BMI_rm$misspassive<-ifelse(BMI_rm$PASSIVESMOKER == "Missing", 1, 0)


CO_var2<-c("ID", "MATCHID.x", "CO_exp", "AgeBloodDraw", "CACO.x",
           "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
           "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
           "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
           "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
           "nopassive", "misspassive", "BMI", "FV_UPDATED", sig_CO_met$COMP_ID)
CO_new2<-BMI_rm[, CO_var2]


M_CO <- CO_new2[, grepl("X", colnames(CO_new2), fixed = T)] # I like to label metabolic features with this prefix
drop_CO <- c("SEX1")
M_CO = M_CO[,!(names(M_CO) %in% drop_CO)]

hima_fit_CO <- hima(X = CO_new2$CO_exp,
                    Y = CO_new2$CACO.x,
                    M = M_CO,
                    COV.XM = CO_new2[, c("AgeBloodDraw",
                                         "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
                                         "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
                                         "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
                                         "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
                                         "nopassive", "misspassive", "BMI", "FV_UPDATED")],
                    Y.family = "binomial",
                    M.family = "gaussian",
                    penalty = "MCP",
                    scale = TRUE,
                    verbose = TRUE)


CO_names<-rownames(hima_fit_CO)
hima_fit_CO<-cbind(CO_names, hima_fit_CO)


###NO2 exposure
#Create metabolite dataframe (M_NO2_impute)
NO2_var<-c("ID", "MATCHID.x", "NO2_exp", "AgeBloodDraw", "CACO.x",
           "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
           "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
           "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
           "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
           "nopassive", "misspassive", "BMI", "FV_UPDATED", sig_NO2_met$COMP_ID)
NO2_new<-BMI_rm[, NO2_var]

M_NO2 <- NO2_new[, grepl("X", colnames(NO2_new), fixed = T)] # I like to label metabolic features with this prefix
drop_NO2 <- c("SEX1")
M_NO2 = M_NO2[,!(names(M_NO2) %in% drop_NO2)]

hima_fit_NO2 <- hima(X = NO2_new$NO2_exp,
                    Y = NO2_new$CACO.x,
                    M = M_NO2,
                    COV.XM = NO2_new[, c("AgeBloodDraw",
                                         "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
                                         "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
                                         "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
                                         "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
                                         "nopassive", "misspassive", "BMI", "FV_UPDATED")],
                    Y.family = "binomial",
                    M.family = "gaussian",
                    penalty = "MCP",
                    scale = TRUE,
                    verbose = TRUE)

NO2_names<-rownames(hima_fit_NO2)
hima_fit_NO2<-cbind(NO2_names, hima_fit_NO2)


###O3 exposure
#Create metabolite dataframe (M_O3_impute)
O3_var<-c("ID", "MATCHID.x", "O3_exp", "AgeBloodDraw", "CACO.x",
           "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
           "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
           "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
           "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
           "nopassive", "misspassive", "BMI", "FV_UPDATED", sig_O3_met$COMP_ID)
O3_new<-BMI_rm[, O3_var]

M_O3 <- O3_new[, grepl("X", colnames(O3_new), fixed = T)] # I like to label metabolic features with this prefix
drop_O3 <- c("SEX1")
M_O3 = M_O3[,!(names(M_O3) %in% drop_O3)]

hima_fit_O3 <- hima(X = O3_new$O3_exp,
                     Y = O3_new$CACO.x,
                     M = M_O3,
                     COV.XM = NO2_new[, c("AgeBloodDraw",
                                          "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
                                          "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
                                          "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
                                          "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
                                          "nopassive", "misspassive", "BMI", "FV_UPDATED")],
                     Y.family = "binomial",
                     M.family = "gaussian",
                     penalty = "MCP",
                     scale = TRUE,
                     verbose = TRUE)

O3_names<-rownames(hima_fit_O3)
hima_fit_O3<-cbind(O3_names, hima_fit_O3)


###PM10 exposure
#Create metabolite dataframe (M_PM10_impute)
PM10_var<-c("ID", "MATCHID.x", "PM10_exp", "AgeBloodDraw", "CACO.x",
           "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
           "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
           "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
           "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
           "nopassive", "misspassive", "BMI", "FV_UPDATED", sig_PM10_met$COMP_ID)
PM10_new<-BMI_rm[, PM10_var]

M_PM10 <- PM10_new[, grepl("X", colnames(PM10_new), fixed = T)] # I like to label metabolic features with this prefix
drop_PM10 <- c("SEX1")
M_PM10 = M_PM10[,!(names(M_PM10) %in% drop_PM10)]

hima_fit_PM10 <- hima(X = PM10_new$PM10_exp,
                     Y = PM10_new$CACO.x,
                     M = M_PM10,
                     COV.XM = PM10_new[, c("AgeBloodDraw",
                                          "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
                                          "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
                                          "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
                                          "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
                                          "nopassive", "misspassive", "BMI", "FV_UPDATED")],
                     Y.family = "binomial",
                     M.family = "gaussian",
                     penalty = "MCP",
                     scale = TRUE,
                     verbose = TRUE)

PM10_names<-rownames(hima_fit_PM10)
hima_fit_PM10<-cbind(PM10_names, hima_fit_PM10)


###PM25 exposure
#Create metabolite dataframe (M_PM25_impute)
PM25_var<-c("ID", "MATCHID.x", "PM25_exp", "AgeBloodDraw", "CACO.x",
           "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
           "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
           "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
           "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
           "nopassive", "misspassive", "BMI", "FV_UPDATED", sig_PM25_met$COMP_ID)
PM25_new<-BMI_rm[, PM25_var]

M_PM25 <- PM25_new[, grepl("X", colnames(PM25_new), fixed = T)] # I like to label metabolic features with this prefix
drop_PM25 <- c("SEX1")
M_PM25 = M_PM25[,!(names(M_PM25) %in% drop_PM25)]

hima_fit_PM25 <- hima(X = PM25_new$PM25_exp,
                     Y = PM25_new$CACO.x,
                     M = M_PM25,
                     COV.XM = PM25_new[, c("AgeBloodDraw",
                                          "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
                                          "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
                                          "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
                                          "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
                                          "nopassive", "misspassive", "BMI", "FV_UPDATED")],
                     Y.family = "binomial",
                     M.family = "gaussian",
                     penalty = "MCP",
                     scale = TRUE,
                     verbose = TRUE)

PM25_names<-rownames(hima_fit_PM25)
hima_fit_PM25<-cbind(PM25_names, hima_fit_PM25)


###SO2 exposure
#Create metabolite dataframe (M_SO2_impute)
SO2_var<-c("ID", "MATCHID.x", "SO2_exp", "AgeBloodDraw", "CACO.x",
           "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
           "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
           "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
           "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
           "nopassive", "misspassive", "BMI", "FV_UPDATED", sig_SO2_met$COMP_ID)
SO2_new<-BMI_rm[, SO2_var]

M_SO2 <- SO2_new[, grepl("X", colnames(SO2_new), fixed = T)] # I like to label metabolic features with this prefix
drop_SO2 <- c("SEX1")
M_SO2 = M_SO2[,!(names(M_SO2) %in% drop_SO2)]

hima_fit_SO2 <- hima(X = SO2_new$SO2_exp,
                     Y = SO2_new$CACO.x,
                     M = M_SO2,
                     COV.XM = SO2_new[, c("AgeBloodDraw",
                                          "SEX1", "RACE1", "uHS", "HS", "someCol", "Col", "beCol",
                                          "missedu", "recentMVUSE", "somewhatrecentMVUSE", "rarelyMVUSE",
                                          "missMVUSE", "noneALC", "under1ALC", "over1ALC", "missALC",
                                          "neversmoker", "currentsmoker", "formersmoker", "yespassive", 
                                          "nopassive", "misspassive", "BMI", "FV_UPDATED")],
                     Y.family = "binomial",
                     M.family = "gaussian",
                     penalty = "MCP",
                     scale = TRUE,
                     verbose = TRUE)

SO2_names<-rownames(hima_fit_SO2)
hima_fit_SO2<-cbind(SO2_names, hima_fit_SO2)

