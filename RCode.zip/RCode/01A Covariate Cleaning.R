#####04022024 Covariate Cleaning

library(haven)
library(plyr)
library(tidyverse)
library(openxlsx)
library(BERGMets)
library(table1)
library(Hmisc)
library(readxl)

setwd("C:/Users/schow4/OneDrive - Emory University/Research/AP-LC/Replication/Data")


##Load Datasets
load("Lung cancer metabolomics - 28Oct2021.Rdata")
load("original.Rda")
fruit<-read_xlsx("subtype.xlsx") #New Fruit/Veg data

#Remove controls that became cases (Should be 7)
fruit_dupIDs <- fruit$ID[duplicated(fruit$ID)]
fruit <- filter(fruit, !(fruit$ID %in% fruit_dupIDs & fruit$CACO=="Control"))

total1_dupIDs<-total1$ID[duplicated(total1$ID)]
total1 <- filter(total1, !(total1$ID %in% total1_dupIDs & total1$CACO=="Control"))

#Merge datasets together
total<-merge(total1, fruit, by = "ID")

#Recode fruit/veggie variable
total$FV_UPDATED<-ifelse(total$FV_UPDATED == ".", NA, total$FV_UPDATED)
total$FV_UPDATED<-ifelse(total$COHORT == "CPS-2", total$FV_UPDATED, total$FruitsVeggiesWeek)

####AP Characterization
total$misalign<-ifelse(total$BloodDrawYear < 1999, 1, 0)

##CO
total$CO_exp<-ifelse(total$BloodDrawYear == 1998, total$CO_1999,
                     ifelse(total$BloodDrawYear == 1999, total$CO_1999,
                            ifelse(total$BloodDrawYear == 2000, total$CO_2000,
                                   ifelse(total$BloodDrawYear == 2001, total$CO_2001,
                                          ifelse(total$BloodDrawYear == 2006, total$CO_2006,
                                                 ifelse(total$BloodDrawYear == 2007, total$CO_2007,
                                                        ifelse(total$BloodDrawYear == 2008, total$CO_2008,
                                                               ifelse(total$BloodDrawYear == 2009, total$CO_2009,
                                                                      ifelse(total$BloodDrawYear == 2010, total$CO_2010,
                                                                             ifelse(total$BloodDrawYear == 2011, total$CO_2011,
                                                                                    ifelse(total$BloodDrawYear == 2012, total$CO_2012,
                                                                                           ifelse(total$BloodDrawYear == 2013, total$CO_2013, NA))))))))))))

##NO2
total$NO2_exp<-ifelse(total$BloodDrawYear == 1998, total$NO2_1999,
                      ifelse(total$BloodDrawYear == 1999, total$NO2_1999,
                             ifelse(total$BloodDrawYear == 2000, total$NO2_2000,
                                    ifelse(total$BloodDrawYear == 2001, total$NO2_2001,
                                           ifelse(total$BloodDrawYear == 2006, total$NO2_2006,
                                                  ifelse(total$BloodDrawYear == 2007, total$NO2_2007,
                                                         ifelse(total$BloodDrawYear == 2008, total$NO2_2008,
                                                                ifelse(total$BloodDrawYear == 2009, total$NO2_2009,
                                                                       ifelse(total$BloodDrawYear == 2010, total$NO2_2010,
                                                                              ifelse(total$BloodDrawYear == 2011, total$NO2_2011,
                                                                                     ifelse(total$BloodDrawYear == 2012, total$NO2_2012,
                                                                                            ifelse(total$BloodDrawYear == 2013, total$NO2_2013, NA))))))))))))

##O3

total$O3_exp<-ifelse(total$BloodDrawYear == 1998, total$O3_1999,
                     ifelse(total$BloodDrawYear == 1999, total$O3_1999,
                            ifelse(total$BloodDrawYear == 2000, total$O3_2000,
                                   ifelse(total$BloodDrawYear == 2001, total$O3_2001,
                                          ifelse(total$BloodDrawYear == 2006, total$O3_2006,
                                                 ifelse(total$BloodDrawYear == 2007, total$O3_2007,
                                                        ifelse(total$BloodDrawYear == 2008, total$O3_2008,
                                                               ifelse(total$BloodDrawYear == 2009, total$O3_2009,
                                                                      ifelse(total$BloodDrawYear == 2010, total$O3_2010,
                                                                             ifelse(total$BloodDrawYear == 2011, total$O3_2011,
                                                                                    ifelse(total$BloodDrawYear == 2012, total$O3_2012,
                                                                                           ifelse(total$BloodDrawYear == 2013, total$O3_2013, NA))))))))))))


##PM10

total$PM10_exp<-ifelse(total$BloodDrawYear == 1998, total$PM10_1999,
                       ifelse(total$BloodDrawYear == 1999, total$PM10_1999,
                              ifelse(total$BloodDrawYear == 2000, total$PM10_2000,
                                     ifelse(total$BloodDrawYear == 2001, total$PM10_2001,
                                            ifelse(total$BloodDrawYear == 2006, total$PM10_2006,
                                                   ifelse(total$BloodDrawYear == 2007, total$PM10_2007,
                                                          ifelse(total$BloodDrawYear == 2008, total$PM10_2008,
                                                                 ifelse(total$BloodDrawYear == 2009, total$PM10_2009,
                                                                        ifelse(total$BloodDrawYear == 2010, total$PM10_2010,
                                                                               ifelse(total$BloodDrawYear == 2011, total$PM10_2011,
                                                                                      ifelse(total$BloodDrawYear == 2012, total$PM10_2012,
                                                                                             ifelse(total$BloodDrawYear == 2013, total$PM10_2013, NA))))))))))))


##PM2.5

total$PM25_exp<-ifelse(total$BloodDrawYear == 1998, total$PM25_1999,
                       ifelse(total$BloodDrawYear == 1999, total$PM25_1999,
                              ifelse(total$BloodDrawYear == 2000, total$PM25_2000,
                                     ifelse(total$BloodDrawYear == 2001, total$PM25_2001,
                                            ifelse(total$BloodDrawYear == 2006, total$PM25_2006,
                                                   ifelse(total$BloodDrawYear == 2007, total$PM25_2007,
                                                          ifelse(total$BloodDrawYear == 2008, total$PM25_2008,
                                                                 ifelse(total$BloodDrawYear == 2009, total$PM25_2009,
                                                                        ifelse(total$BloodDrawYear == 2010, total$PM25_2010,
                                                                               ifelse(total$BloodDrawYear == 2011, total$PM25_2011,
                                                                                      ifelse(total$BloodDrawYear == 2012, total$PM25_2012,
                                                                                             ifelse(total$BloodDrawYear == 2013, total$PM25_2013, NA))))))))))))


##SO2

test<-total
test$SO2<-ifelse(test$BloodDrawYear == 1998, total$SO2_1999, NA)
sum(is.na(test$SO2))


total$SO2_exp<-ifelse(total$BloodDrawYear == 1998, total$SO2_1999,
                      ifelse(total$BloodDrawYear == 1999, total$SO2_1999,
                             ifelse(total$BloodDrawYear == 2000, total$SO2_2000,
                                    ifelse(total$BloodDrawYear == 2001, total$SO2_2001,
                                           ifelse(total$BloodDrawYear == 2006, total$SO2_2006,
                                                  ifelse(total$BloodDrawYear == 2007, total$SO2_2007,
                                                         ifelse(total$BloodDrawYear == 2008, total$SO2_2008,
                                                                ifelse(total$BloodDrawYear == 2009, total$SO2_2009,
                                                                       ifelse(total$BloodDrawYear == 2010, total$SO2_2010,
                                                                              ifelse(total$BloodDrawYear == 2011, total$SO2_2011,
                                                                                     ifelse(total$BloodDrawYear == 2012, total$SO2_2012,
                                                                                            ifelse(total$BloodDrawYear == 2013, total$SO2_2013, NA))))))))))))

#these should all be 61
sum(is.na(total$CO_exp)) 
sum(is.na(total$NO2_exp))
sum(is.na(total$O3_exp))
sum(is.na(total$PM10_exp))
sum(is.na(total$PM25_exp))
sum(is.na(total$SO2_exp))


###Other covariate cleaning
##Remove matched case control studies
trachea <- total$ID[total$TRACHEA_CASE.x==1]
tracheamatchID <- total$MATCHID.x[total$ID %in% trachea]
total <- total[!total$MATCHID.x %in% tracheamatchID, ]

insitus <- total$ID[total$STAGE == 0 & !is.na(total$STAGE)]
insitusmatchID<-total$MATCHID.x[total$ID %in% insitus]
#insitusmatchID <- stage$MATCHID[stage$ID %in% insitus]
total <- total[!total$MATCHID.x %in% insitusmatchID, ]

#Remove missing air pollution assessment peeps (KEEP matched pairs. only remove participants w/missing data)

total$missing<- ifelse(is.na(total$CO_exp), 1, 0)
table(total$missing)
missing<-total$ID[total$missing==1]
#missingmatchID <- total$MATCHID.x[total$ID %in% missing]
total <- total[!total$ID %in% missing, ]

#Remove extra control in CPS-II
print(total[total$MATCHID== "91",1:22 ])
table(total$CACO.x, total$COHORT,useNA = "ifany")
total <- total[!total$ID %in% '23009003008092', ]
table(total$CACO.x, total$COHORT,useNA = "ifany")


#LC Stage

total$STAGE <- as.factor(total$STAGE)
table(total$STAGE,useNA = "ifany")
total$LCstage <- ifelse(is.na(total$STAGE), 9,
                        ifelse(total$STAGE == 1 , 1,
                               ifelse (total$STAGE == 2 | total$STAGE == 3 | total$STAGE == 4, 2,
                                       ifelse (total$STAGE == 7, 3, 4))))
total$LCstage <- with(total, factor(total$LCstage,
                                    levels = c(1, 2, 3, 4, 9),
                                    labels = c("Localized", "Regional", "Distant", "Unknown", "Missing")))
table(total$LCstage)
#Sex
total$SEX<- with(total, factor(SEX, levels = c("Female", "Male"),
                               labels = c("Female", "Male")))
table(total$SEX, useNA = "ifany")

# Race
table(total$RACE, total$COHORT, useNA = "ifany")
total$RACE<- with(total, factor(RACE, 
                                levels=c("American Indian", "Asian", "Black", "Hawaiian", "Hispanic", "Missing", "Other", "White"),
                                labels=c("Non-White", "Non-White", "Non-White", "Non-White",  "Non-White", "Missing", "Non-White", "White")))



# HRTCURR
table(total$SEX, total$HRTCURR, total$COHORT, useNA="ifany")
total$HRTCURRGROUP <- total$HRTCURR
CPS3males <- total[total$COHORT=="CPS-3" & total$SEX == "Male", "ID"]
total$HRTCURRGROUP <- ifelse(total$ID %in% CPS3males, NA, total$HRTCURRGROUP)
table(total$SEX, total$HRTCURRGROUP, total$COHORT, useNA="ifany")
total$HRTCURRGROUP <- with(total, factor(HRTCURRGROUP, 
                                         levels=c(1,2, NA, 3), exclude = NULL, 
                                         labels=c("Not a current user", "Current user", "Not applicable", NA)))

total$HRTCURRGROUP <- with(total, factor(HRTCURRGROUP, 
                                         levels=c("Not a current user", "Current user", "Not applicable")))
table(total$HRTCURRGROUP, total$COHORT, useNA = "ifany")


## Smoking status: 4 categories
table(total$SmokingVariable, useNA = "ifany")
total$Smokegroup1 <- ifelse(total$SmokingVariable=="Missing smoking status", NA, as.character(total$SmokingVariable))
total$Smokegroup1<- with(total, factor(Smokegroup1, 
                                       levels=c("Never smoker", "Current < 25cpd / <50 years", "Current < 25cpd / 50+ years", "Current 25+ cpd / <50 years", "Current 25+ cpd / 50+ years",
                                                "Current, unknown cpd or duration", "Former <5 years", "Former 5-9 years", "Former 10-14 years", "Former 15-19 years",
                                                "Former 20-24 years", "Former 25+ years", "Former unknown years"), 
                                       labels=c("Never", "Current", "Current", "Current", "Current",
                                                "Current", "Former", "Former", "Former", "Former", "Former", "Former","Former")))

total$missing<- ifelse(is.na(total$Smokegroup1), 1, 0)
table(total$missing)
missing<-total$ID[total$missing==1]
#missingmatchID <- total$MATCHID.x[total$ID %in% missing]
total <- total[!total$ID %in% missing, ]

#Also make a new binary smoking status variable (ever/never)
total$smoke_binary<-with(total, factor(Smokegroup1,
                                       levels=c("Never","Current","Former"),
                                       labels=c("Never", "Ever", "Ever")))
table(total$smoke_binary)
table(total$Smokegroup1)

##Education level
table(total$EDUCGRP)
total$EDUCGRP <- ifelse(total$EDUCGRP=="Missing", NA, total$EDUCGRP)
total$EDUCGRP<- with(total, factor(EDUCGRP, 
                                   levels=c(1, 2, 3, 4, 5, 9),
                                   labels=c("Less than HS", "HS Graduate", "Some College/Tech School/2-year Degree", "College Graduate",  "Graduate School", "Missing")))
table(total$EDUCGRP, total$COHORT, useNA = "ifany")
total$EDUCGRP<-relevel(total$EDUCGRP, ref = "College Graduate")

#Multivitamin Use

table(total$MVUSE, useNA = "ifany")
total$MVUSE<-ifelse(total$MVUSE=="Missing", NA, total$MVUSE)
total$MVUSE<-ifelse(total$MVUSE == 1, 1,
                    ifelse(total$MVUSE == 2, 1,
                           ifelse(total$MVUSE == 3, 2,
                                  ifelse(total$MVUSE == 4, 2,
                                         ifelse(total$MVUSE == 5, 3,
                                                ifelse(total$MVUSE == 9, 9, 0))))))
table(total$MVUSE)
sum(is.na(total$MVUSE))
total$MVUSE<- with(total, factor(MVUSE, 
                                 levels=c(1, 2, 3, 9),
                                 labels=c("Recently", "Somewhat Recently",  "Rarely/Never", "Missing")))
table(total$MVUSE, total$CACO.x, useNA = "ifany")


##Family History of Lung Cancer
table(total$FAMHXLG)
total$FAMHXLG <- ifelse(total$FAMHXLG=="Missing", NA, total$FAMHXLG)
total$FAMHXLG<- with(total, factor(FAMHXLG, 
                                   levels=c(1, 0, 9),
                                   labels=c("Yes",  "No", "Missing")))
table(total$FAMHXLG, total$COHORT, useNA = "ifany")

##Passive Smoke Exposure
table(total$PASSIVESMOKER)
total$PASSIVESMOKER <- ifelse(total$PASSIVESMOKER=="Missing", NA, total$PASSIVESMOKER)
total$PASSIVESMOKER<- with(total, factor(PASSIVESMOKER, 
                                         levels=c(1, 0, 9),
                                         labels=c("Yes",  "No", "Missing")))
table(total$PASSIVESMOKER, total$COHORT, useNA = "ifany")

##Alcohol
table(total$ALC)
total$ALC <- ifelse(total$ALC=="Missing", NA,
                    ifelse(total$ALC == 0, 0,
                           ifelse(total$ALC == 1, 1,
                                  ifelse(total$ALC == 2, 2,
                                         ifelse(total$ALC == 3, 2, 9)))))
table(total$ALC)


total$ALC<- with(total, factor(ALC, 
                               levels=c(0, 1, 2, 9),
                               labels=c("None",  "<1 per day", "1+ per day", "Missing")))
table(total$ALC, total$COHORT, useNA = "ifany")

##Marital Status
table(total$MS)
total$MS <- ifelse(total$MS=="Missing", NA, total$MS)
total$MS<- with(total, factor(MS, 
                              levels=c(1, 2, 3),
                              labels=c("Single",  "Married", "Other")))
table(total$MS, total$COHORT, useNA = "ifany")

###Final sample size n = 1359
dim(total)
#1359 481 <-should be this

