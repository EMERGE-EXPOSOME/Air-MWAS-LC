library(dplyr)
getwd()
setwd("C:/Users/schow4/OneDrive - Emory University/Research/AP-LC/CPS Lung Cancer Dataset/Data Files/Revisions")

morbidity<-read_xlsx("CPS_LUNG_NEWVARS_JUNE2025.XLSX")

#############################################################################
##############PREP DATA FOR FIVE-YEAR MOVING AVERAGE VALUE###################
#############################################################################

####Create New Exposure variables
blooddraw<-subset(dtscaled, select = c("ID", "BloodDrawYear"))


morbidity <- morbidity[!duplicated(morbidity$ID), ] ##Remove duplicated ID's
morbidity<-merge(blooddraw, morbidity, by = "ID")
table(morbidity$BloodDrawYear)
morbidity$BloodDrawYear<-as.numeric(morbidity$BloodDrawYear)

###Convert all pollutant info to numeric
morbidity1<-morbidity
morbidity1[, c(11:222)]<-lapply(morbidity1[, c(11:222)], as.numeric)

# Define your list of pollutants
pollutants <- c("CO", "NO2", "O3", "PM10", "PM25", "SO2")
target_years<- c(1998:2001, 2007:2013)

fiveyravg <- function(df, exposures, target_years) {
  
  for (exposure in exposures) {
    for (year in target_years) {
      # Get the 5-year window column names
      window_cols <- paste0(exposure, "_", (year-4):year)
      existing_cols <- window_cols[window_cols %in% names(df)]
      
      # Create new column name
      new_col_name <- paste0(exposure, "_5yr_avg_", year)
      
      if (length(existing_cols) == 5) {
        
        # Calculate rowwise mean using dplyr
        df <- df %>%
          rowwise() %>%
          mutate(!!new_col_name := mean(c_across(all_of(existing_cols)), na.rm = TRUE)) %>%
          ungroup()
      } else {
        # Assign NA when fewer than 5 columns exist
        df[[new_col_name]] <- NA_real_
      }
    }
  }
  
  return(df)
}

morbidity1<-fiveyravg(morbidity1, pollutants, target_years)



morbidity1$CO_fiveyr<-
  ifelse(morbidity1$BloodDrawYear == 1998, morbidity1$CO_5yr_avg_1998,
         ifelse(morbidity1$BloodDrawYear == 1999, morbidity1$CO_5yr_avg_1999,
                ifelse(morbidity1$BloodDrawYear == 2000, morbidity1$CO_5yr_avg_2000,
                       ifelse(morbidity1$BloodDrawYear == 2001, morbidity1$CO_5yr_avg_2001,
                              ifelse(morbidity1$BloodDrawYear == 2007, morbidity1$CO_5yr_avg_2007,
                                     ifelse(morbidity1$BloodDrawYear == 2008, morbidity1$CO_5yr_avg_2008,
                                            ifelse(morbidity1$BloodDrawYear == 2009, morbidity1$CO_5yr_avg_2009,
                                                   ifelse(morbidity1$BloodDrawYear == 2010, morbidity1$CO_5yr_avg_2010,
                                                          ifelse(morbidity1$BloodDrawYear == 2011, morbidity1$CO_5yr_avg_2011,
                                                                 ifelse(morbidity1$BloodDrawYear == 2012, morbidity1$CO_5yr_avg_2012,
                                                                        ifelse(morbidity1$BloodDrawYear == 2013, morbidity1$CO_5yr_avg_2013, NA)))))))))))
table(morbidity1$CO_fiveyr, useNA = "ifany")

morbidity1$NO2_fiveyr<-ifelse(morbidity1$BloodDrawYear == 1998, morbidity1$NO2_5yr_avg_1998,
                              ifelse(morbidity1$BloodDrawYear == 1999, morbidity1$NO2_5yr_avg_1999,
                                     ifelse(morbidity1$BloodDrawYear == 2000, morbidity1$NO2_5yr_avg_2000,
                                            ifelse(morbidity1$BloodDrawYear == 2001, morbidity1$NO2_5yr_avg_2001,
                                                   ifelse(morbidity1$BloodDrawYear == 2007, morbidity1$NO2_5yr_avg_2007,
                                                          ifelse(morbidity1$BloodDrawYear == 2008, morbidity1$NO2_5yr_avg_2008,
                                                                 ifelse(morbidity1$BloodDrawYear == 2009, morbidity1$NO2_5yr_avg_2009,
                                                                        ifelse(morbidity1$BloodDrawYear == 2010, morbidity1$NO2_5yr_avg_2010,
                                                                               ifelse(morbidity1$BloodDrawYear == 2011, morbidity1$NO2_5yr_avg_2011,
                                                                                      ifelse(morbidity1$BloodDrawYear == 2012, morbidity1$NO2_5yr_avg_2012,
                                                                                             ifelse(morbidity1$BloodDrawYear == 2013, morbidity1$NO2_5yr_avg_2013, NA)))))))))))

morbidity1$O3_fiveyr<-ifelse(morbidity1$BloodDrawYear == 1998, morbidity1$O3_5yr_avg_1998,
                             ifelse(morbidity1$BloodDrawYear == 1999, morbidity1$O3_5yr_avg_1999,
                                    ifelse(morbidity1$BloodDrawYear == 2000, morbidity1$O3_5yr_avg_2000,
                                           ifelse(morbidity1$BloodDrawYear == 2001, morbidity1$O3_5yr_avg_2001,
                                                  ifelse(morbidity1$BloodDrawYear == 2007, morbidity1$O3_5yr_avg_2007,
                                                         ifelse(morbidity1$BloodDrawYear == 2008, morbidity1$O3_5yr_avg_2008,
                                                                ifelse(morbidity1$BloodDrawYear == 2009, morbidity1$O3_5yr_avg_2009,
                                                                       ifelse(morbidity1$BloodDrawYear == 2010, morbidity1$O3_5yr_avg_2010,
                                                                              ifelse(morbidity1$BloodDrawYear == 2011, morbidity1$O3_5yr_avg_2011,
                                                                                     ifelse(morbidity1$BloodDrawYear == 2012, morbidity1$O3_5yr_avg_2012,
                                                                                            ifelse(morbidity1$BloodDrawYear == 2013, morbidity1$O3_5yr_avg_2013, NA)))))))))))


morbidity1$PM10_fiveyr<-ifelse(morbidity1$BloodDrawYear == 1998, morbidity1$PM10_5yr_avg_1998,
                               ifelse(morbidity1$BloodDrawYear == 1999, morbidity1$PM10_5yr_avg_1999,
                                      ifelse(morbidity1$BloodDrawYear == 2000, morbidity1$PM10_5yr_avg_2000,
                                             ifelse(morbidity1$BloodDrawYear == 2001, morbidity1$PM10_5yr_avg_2001,
                                                    ifelse(morbidity1$BloodDrawYear == 2007, morbidity1$PM10_5yr_avg_2007,
                                                           ifelse(morbidity1$BloodDrawYear == 2008, morbidity1$PM10_5yr_avg_2008,
                                                                  ifelse(morbidity1$BloodDrawYear == 2009, morbidity1$PM10_5yr_avg_2009,
                                                                         ifelse(morbidity1$BloodDrawYear == 2010, morbidity1$PM10_5yr_avg_2010,
                                                                                ifelse(morbidity1$BloodDrawYear == 2011, morbidity1$PM10_5yr_avg_2011,
                                                                                       ifelse(morbidity1$BloodDrawYear == 2012, morbidity1$PM10_5yr_avg_2012,
                                                                                              ifelse(morbidity1$BloodDrawYear == 2013, morbidity1$PM10_5yr_avg_2013, NA)))))))))))

####NOt able to do for all participants
morbidity1$PM25_fiveyr<-ifelse(morbidity1$BloodDrawYear == 1998, morbidity1$PM25_5yr_avg_1998,
                               ifelse(morbidity1$BloodDrawYear == 1999, morbidity1$PM25_5yr_avg_1999,
                                      ifelse(morbidity1$BloodDrawYear == 2000, morbidity1$PM25_5yr_avg_2000,
                                             ifelse(morbidity1$BloodDrawYear == 2001, morbidity1$PM25_5yr_avg_2001,
                                                    ifelse(morbidity1$BloodDrawYear == 2007, morbidity1$PM25_5yr_avg_2007,
                                                           ifelse(morbidity1$BloodDrawYear == 2008, morbidity1$PM25_5yr_avg_2008,
                                                                  ifelse(morbidity1$BloodDrawYear == 2009, morbidity1$PM25_5yr_avg_2009,
                                                                         ifelse(morbidity1$BloodDrawYear == 2010, morbidity1$PM25_5yr_avg_2010,
                                                                                ifelse(morbidity1$BloodDrawYear == 2011, morbidity1$PM25_5yr_avg_2011,
                                                                                       ifelse(morbidity1$BloodDrawYear == 2012, morbidity1$PM25_5yr_avg_2012,
                                                                                              ifelse(morbidity1$BloodDrawYear == 2013, morbidity1$PM25_5yr_avg_2013, NA)))))))))))


morbidity1$SO2_fiveyr<-ifelse(morbidity1$BloodDrawYear == 1998, morbidity1$SO2_5yr_avg_1998,
                              ifelse(morbidity1$BloodDrawYear == 1999, morbidity1$SO2_5yr_avg_1999,
                                     ifelse(morbidity1$BloodDrawYear == 2000, morbidity1$SO2_5yr_avg_2000,
                                            ifelse(morbidity1$BloodDrawYear == 2001, morbidity1$SO2_5yr_avg_2001,
                                                   ifelse(morbidity1$BloodDrawYear == 2007, morbidity1$SO2_5yr_avg_2007,
                                                          ifelse(morbidity1$BloodDrawYear == 2008, morbidity1$SO2_5yr_avg_2008,
                                                                 ifelse(morbidity1$BloodDrawYear == 2009, morbidity1$SO2_5yr_avg_2009,
                                                                        ifelse(morbidity1$BloodDrawYear == 2010, morbidity1$SO2_5yr_avg_2010,
                                                                               ifelse(morbidity1$BloodDrawYear == 2011, morbidity1$SO2_5yr_avg_2011,
                                                                                      ifelse(morbidity1$BloodDrawYear == 2012, morbidity1$SO2_5yr_avg_2012,
                                                                                             ifelse(morbidity1$BloodDrawYear == 2013, morbidity1$SO2_5yr_avg_2013, NA)))))))))))



################################
###Sensitivity Analyses#########
###5-yr Moving Avg Exposure#####
################################
sig_met<-c("X61771", "X48442", "X32412", "X2730", "X44872", "X31536", "X52925", "X49531")

five_yr_exp<-c("CO_fiveyr", "NO2_fiveyr", "O3_fiveyr", "PM10_fiveyr", "PM25_fiveyr", "SO2_fiveyr")

five_var_list<-c(five_yr, "AgeBloodDraw", "SEX", "RACE", "BMI", "EDUCGRP", "MVUSE",
                 "FV_UPDATED", "ALC", "Smokegroup1", "PASSIVESMOKER", "FAMHXLG", "CACO.x", sig_met)

five_yr<-subset(morbidity1, select = c("ID", "CO_fiveyr", "NO2_fiveyr", "O3_fiveyr", "PM10_fiveyr", "PM25_fiveyr", "SO2_fiveyr"))

dtscaled_fiveyr<-merge(five_yr, dtscaled, by = "ID")
dtscaled_fiveyr[,c(486:1624)]<-lapply(dtscaled_fiveyr[,c(486:1624)], as.vector)

five_yr<-subset(dtscaled_fiveyr, select = five_var_list)
###Metabolites now start at 487

# Initialize list to store result dataframes and MWAS summary
fiveyr_results <- list()

five_yr_exposure<-c("CO_fiveyr", "NO2_fiveyr", "O3_fiveyr", "PM10_fiveyr", "SO2_fiveyr")

# Loop through each pollutant
for (exposure in five_yr_exposure) {
  
  # Create empty dataframe to hold regression results
  temp_result <- data.frame(matrix(nrow = 8, ncol = 6))
  colnames(temp_result) <- c("Est", "Std", "t-value", "P", "LowerCI", "UpperCI")
  
  for (i in 1:(nrow(biochem.blood) - length(removemet))) {
    tryCatch({
      formula <- as.formula(
        paste0("five_yr[, i + 18] ~ ", exposure, " + BMI + AgeBloodDraw + SEX + RACE + ",
               "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
               "factor(ALC) + factor(Smokegroup1) + factor(PASSIVESMOKER)")
      )
      lmfit <- lm(formula, data = five_yr)
      coefs <- summary(lmfit)$coefficients[2, ]
      ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
      temp_result[i, ] <- c(coefs, ci)
    }, error = function(e) {})
  }
  
  # Adjust p-values and attach compound ID
  temp_result$pfdr <- p.adjust(temp_result$P, method = "BH")
  temp_result_met <- cbind(colnames(five_yr)[19:ncol(five_yr)], temp_result)
  colnames(temp_result_met)[1] <- "COMP_ID"
  
  # Store the result in a named list
  result_name <- paste0("fiveyr_", exposure, "_met")
  fiveyr_results[[result_name]] <- temp_result_met
  
  # Store summary statistics
  MWASStat1[kk, ] <- c(
    result_name,
    sum(temp_result_met$P < 0.05, na.rm = TRUE),
    sum(temp_result_met$P < 0.01, na.rm = TRUE),
    sum(temp_result_met$P < 0.005, na.rm = TRUE),
    sum(temp_result_met$P < 0.0005, na.rm = TRUE),
    sum(temp_result_met$pfdr < 0.20, na.rm = TRUE),
    sum(temp_result_met$pfdr < 0.05, na.rm = TRUE)
  )
  
  kk <- kk + 1
}

####LC Analysis
for (exposure in exposures) {
  
  
  LC_result <- data.frame(matrix(nrow = 8, ncol = 6))
  colnames(LC_result) <- c("Est", "Std", "t-value", "P", "LowerCI", "UpperCI")
  
  for (i in 1:8) {
    tryCatch({
      formula <- as.formula(
        paste0("five_yr[, i + 18] ~ factor(CACO.x) + BMI + AgeBloodDraw + SEX + RACE + ",
               "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
               "factor(ALC) + factor(Smokegroup1) + factor(PASSIVESMOKER)")
      )
      lmfit <- lm(formula, data = five_yr)
      coefs <- summary(lmfit)$coefficients[2, ]
      ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
      LC_result[i, ] <- c(coefs, ci)
    }, error = function(e) {})
  }
  
  # Adjust p-values and attach compound ID
  LC_result$pfdr <- p.adjust(temp_result$P, method = "BH")
  LC_result <- cbind(colnames(five_yr)[19:ncol(five_yr)], LC_result)
  colnames(LC_result)[1] <- "COMP_ID"
  
  # Store the result in a named list
  result_name <- paste0("LC_fiveyr", exposure, "_met")
  fiveyr_results[[result_name]] <- LC_result
  
  
  # Store MWAS summary for LC
  MWASStat1[kk, ] <- c(
    paste0(exposure, "_LC_met_fiveyr"),
    sum(LC_met$P < 0.05, na.rm = TRUE),
    sum(LC_met$P < 0.01, na.rm = TRUE),
    sum(LC_met$P < 0.005, na.rm = TRUE),
    sum(LC_met$P < 0.0005, na.rm = TRUE),
    sum(LC_met$pfdr < 0.20, na.rm = TRUE),
    sum(LC_met$pfdr < 0.05, na.rm = TRUE)
  )
  
  kk <- kk + 1
}


library(openxlsx)
wb<-createWorkbook()
addWorksheet(wb, "CO", tabColour = "black")
addWorksheet(wb, "NO2", tabColour = "black")
addWorksheet(wb, "O3", tabColour = "black")
addWorksheet(wb, "PM10", tabColour = "black")
addWorksheet(wb, "SO2", tabColour = "black")
addWorksheet(wb, "LC")
writeData(wb, "CO", fiveyr_results[["fiveyr_CO_fiveyr_met"]], rowNames=T, colNames=T)
writeData(wb, "NO2", fiveyr_results[["fiveyr_NO2_fiveyr_met"]], rowNames=T, colNames=T)
writeData(wb, "O3", fiveyr_results[["fiveyr_O3_fiveyr_met"]], rowNames=T, colNames=T)
writeData(wb, "PM10", fiveyr_results[["fiveyr_PM10_fiveyr_met"]], rowNames=T, colNames=T)
writeData(wb, "SO2", fiveyr_results[["fiveyr_SO2_fiveyr_met"]], rowNames=T, colNames=T)
writeData(wb, "LC", fiveyr_results[["LC_fiveyrCO_exp_met"]], rowNames=T, colNames=T)
saveWorkbook(wb, file="Fiveyr1.xlsx", overwrite=TRUE)


sig_LC_results_fiveyr <- lapply(fiveyr_results, function(df) {
  subset(df, pfdr < 0.2 & !is.na(pfdr))
})

sig_LC_results_fiveyr[["CO_fiveyr_LC_met"]]<-merge(sig_LC_results_fiveyr[["CO_fiveyr_LC_met"]], biochem.blood, by = "COMP_ID")
sig_LC_results_fiveyr[["NO2_fiveyr_LC_met"]]<-merge(sig_LC_results_fiveyr[["NO2_fiveyr_LC_met"]], biochem.blood, by = "COMP_ID")
sig_LC_results_fiveyr[["O3_fiveyr_LC_met"]]<-merge(sig_LC_results_fiveyr[["O3_fiveyr_LC_met"]], biochem.blood, by = "COMP_ID")
sig_LC_results_fiveyr[["PM10_fiveyr_LC_met"]]<-merge(sig_LC_results_fiveyr[["PM10_fiveyr_LC_met"]], biochem.blood, by = "COMP_ID")

write.csv(sig_LC_results_fiveyr[["CO_fiveyr_LC_met"]], file = "CO_fiveyr.csv")
write.csv(sig_LC_results_fiveyr[["NO2_fiveyr_LC_met"]], file = "NO2_fiveyr.csv")
write.csv(sig_LC_results_fiveyr[["O3_fiveyr_LC_met"]], file = "O3_fiveyr.csv")
write.csv(sig_LC_results_fiveyr[["PM10_fiveyr_LC_met"]], file = "PM10_fiveyr.csv")

CO_fiveyr_met<-sig_LC_results_fiveyr[["CO_fiveyr_LC_met"]]$COMP_ID
NO2_fiveyr_met<-sig_LC_results_fiveyr[["NO2_fiveyr_LC_met"]]$COMP_ID
O3_fiveyr_met<-sig_LC_results_fiveyr[["O3_fiveyr_LC_met"]]$COMP_ID
PM10_fiveyr_met<-sig_LC_results_fiveyr[["PM10_fiveyr_LC_met"]]$COMP_ID

five_yr_filter_id<-list(
  dtscaled_fiveyr_CO_fiveyr_met = CO_fiveyr_met,
  dtscaled_fiveyr_NO2_fiveyr_met = NO2_fiveyr_met,
  dtscaled_fiveyr_O3_fiveyr_met = O3_fiveyr_met,
  dtscaled_fiveyr_PM10_fiveyr_met = PM10_fiveyr_met
)

fiveyr_filtered_list <- mapply(function(df, ids) {
  df[df$COMP_ID %in% ids, ]
}, fiveyr_results[names(five_yr_filter_id)], five_yr_filter_id, SIMPLIFY = FALSE)

library(openxlsx)
wb<-createWorkbook()
addWorksheet(wb, "CO", tabColour = "black")
addWorksheet(wb, "NO2", tabColour = "black")
addWorksheet(wb, "O3", tabColour = "black")
addWorksheet(wb, "PM10", tabColour = "black")
writeData(wb, "CO", fiveyr_filtered_list[["dtscaled_fiveyr_CO_fiveyr_met"]], rowNames=T, colNames=T)
writeData(wb, "NO2", fiveyr_filtered_list[["dtscaled_fiveyr_NO2_fiveyr_met"]], rowNames=T, colNames=T)
writeData(wb, "O3", fiveyr_filtered_list[["dtscaled_fiveyr_O3_fiveyr_met"]], rowNames=T, colNames=T)
writeData(wb, "PM10", fiveyr_filtered_list[["dtscaled_fiveyr_PM10_fiveyr_met"]], rowNames=T, colNames=T)
saveWorkbook(wb, file="Fiveyr.xlsx", overwrite=TRUE)

################################
###Sensitivity Analyses#########
###Co-Morbidity Score###########
################################
morbidity_score<-subset(morbidity1, select = c("ID", "HCOMORB"))
dtscaled_morb<-merge(morbidity_score, dtscaled, by = "ID")
dtscaled_fiveyr[,c(482:1619)]<-lapply(dtscaled_fiveyr[,c(482:1619)], as.vector)
###Metabolites now start at 487

# Initialize list to store result dataframes and MWAS summary
morb_results <- list()

# Loop through each pollutant
for (exposure in exposures) {
  
  # Create empty dataframe to hold regression results
  temp_result <- data.frame(matrix(nrow = (nrow(biochem.blood) - length(removemet)), ncol = 6))
  colnames(temp_result) <- c("Est", "Std", "t-value", "P", "LowerCI", "UpperCI")
  
  for (i in 1:(nrow(biochem.blood) - length(removemet))) {
    tryCatch({
      formula <- as.formula(
        paste0("dtscaled_morb[, i + 481] ~ ", exposure, " + BMI + AgeBloodDraw + SEX + RACE + ",
               "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
               "factor(ALC) + factor(Smokegroup1) + factor(PASSIVESMOKER) + factor(HCOMORB)")
      )
      lmfit <- lm(formula, data = dtscaled_morb)
      coefs <- summary(lmfit)$coefficients[2, ]
      ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
      temp_result[i, ] <- c(coefs, ci)
    }, error = function(e) {})
  }
  
  # Adjust p-values and attach compound ID
  temp_result$pfdr <- p.adjust(temp_result$P, method = "BH")
  temp_result_met <- cbind(colnames(dtscaled_morb)[482:ncol(dtscaled_morb)], temp_result)
  colnames(temp_result_met)[1] <- "COMP_ID"
  
  # Store the result in a named list
  result_name <- paste0("dtscaled_morb_", exposure, "_met")
  morb_results[[result_name]] <- temp_result_met
  
  # Store summary statistics
  MWASStat1[kk, ] <- c(
    result_name,
    sum(temp_result_met$P < 0.05, na.rm = TRUE),
    sum(temp_result_met$P < 0.01, na.rm = TRUE),
    sum(temp_result_met$P < 0.005, na.rm = TRUE),
    sum(temp_result_met$P < 0.0005, na.rm = TRUE),
    sum(temp_result_met$pfdr < 0.20, na.rm = TRUE),
    sum(temp_result_met$pfdr < 0.05, na.rm = TRUE)
  )
  
  kk <- kk + 1
}

####LC Analysis
for (exposure in exposures) {
  
  # Retrieve first-stage result
  result_name <- paste0("dtscaled_morb_", exposure, "_met")
  res_df <- morb_results[[result_name]]
  
  # Filter for significant metabolites
  sig_met <- subset(res_df, pfdr < 0.2 & !is.na(pfdr))
  
  if (nrow(sig_met) == 0) {
    # Skip if no significant metabolites
    next
  }
  
  # Build variable list
  met_names <- sig_met$COMP_ID
  var_list <- c(exposure, "AgeBloodDraw", "SEX", "RACE", "BMI", "EDUCGRP", "MVUSE",
                "FV_UPDATED", "ALC", "Smokegroup1", "PASSIVESMOKER", "CACO.x", "HCOMORB", met_names)
  
  # Subset the data
  data_subset <- dtscaled_morb[, var_list]
  
  # Prepare result dataframes
  n_met <- length(met_names)
  LC_df <- data.frame(matrix(nrow = n_met, ncol = 4))
  colnames(LC_df) <- c("Est", "Std", "t-value", "P")
  
  LC_confint <- data.frame(matrix(nrow = n_met, ncol = 2))
  colnames(LC_confint) <- c("Lower", "Upper")
  
  # Run linear models
  for (i in 1:n_met) {
    tryCatch({
      formula <- as.formula(
        paste0("data_subset[, i + 12] ~ factor(CACO.x) + BMI + AgeBloodDraw + SEX + RACE + ",
               "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
               "factor(ALC) + factor(Smokegroup1) + factor(PASSIVESMOKER) + factor(HCOMORB)")
      )
      lmfit <- lm(formula, data = data_subset)
      coef_vals <- summary(lmfit)$coefficients[2, ]
      LC_df[i, ] <- coef_vals
      
      conf_vals <- confint(lmfit)[2, ]
      LC_confint[i, ] <- conf_vals
    }, error = function(e) {})
  }
  
  # Adjust p-values
  LC_df$pfdr <- p.adjust(LC_df$P, method = "BH")
  
  # Combine all results
  LC_met <- cbind(met_names, LC_df, LC_confint)
  colnames(LC_met)[1] <- "COMP_ID"
  
  # Store the final LC result
  morb_results[[paste0(exposure, "_LC_met")]] <- LC_met
  
  # Store MWAS summary for LC
  MWASStat1[kk, ] <- c(
    paste0(exposure, "_LC_met_fiveyr"),
    sum(LC_met$P < 0.05, na.rm = TRUE),
    sum(LC_met$P < 0.01, na.rm = TRUE),
    sum(LC_met$P < 0.005, na.rm = TRUE),
    sum(LC_met$P < 0.0005, na.rm = TRUE),
    sum(LC_met$pfdr < 0.20, na.rm = TRUE),
    sum(LC_met$pfdr < 0.05, na.rm = TRUE)
  )
  
  kk <- kk + 1
}

sig_LC_results_morb <- lapply(morb_results, function(df) {
  subset(df, pfdr < 0.2 & !is.na(pfdr))
})

sig_LC_results_morb[["CO_exp_LC_met"]]<-merge(sig_LC_results_morb[["CO_exp_LC_met"]], biochem.blood, by = "COMP_ID")
sig_LC_results_morb[["NO2_exp_LC_met"]]<-merge(sig_LC_results_morb[["NO2_exp_LC_met"]], biochem.blood, by = "COMP_ID")
sig_LC_results_morb[["O3_exp_LC_met"]]<-merge(sig_LC_results_morb[["O3_exp_LC_met"]], biochem.blood, by = "COMP_ID")
sig_LC_results_morb[["PM10_exp_LC_met"]]<-merge(sig_LC_results_morb[["PM10_exp_LC_met"]], biochem.blood, by = "COMP_ID")
sig_LC_results_morb[["PM25_exp_LC_met"]]<-merge(sig_LC_results_morb[["PM25_exp_LC_met"]], biochem.blood, by = "COMP_ID")
sig_LC_results_morb[["SO2_exp_LC_met"]]<-merge(sig_LC_results_morb[["SO2_exp_LC_met"]], biochem.blood, by = "COMP_ID")


write.csv(sig_LC_results_morb[["CO_exp_LC_met"]], file = "CO_morb.csv")
write.csv(sig_LC_results_morb[["NO2_exp_LC_met"]], file = "NO2_morb.csv")
write.csv(sig_LC_results_morb[["O3_exp_LC_met"]], file = "O3_morb.csv")
write.csv(sig_LC_results_morb[["PM10_exp_LC_met"]], file = "PM10_morb.csv")
write.csv(sig_LC_results_morb[["PM25_exp_LC_met"]], file = "PM25_morb.csv")
write.csv(sig_LC_results_morb[["SO2_exp_LC_met"]], file = "SO2_morb.csv")


###pull the AP data
CO_comorb_met<-sig_LC_results_morb[["CO_exp_LC_met"]]$COMP_ID
NO2_comorb_met<-sig_LC_results_morb[["NO2_exp_LC_met"]]$COMP_ID
O3_comorb_met<-sig_LC_results_morb[["O3_exp_LC_met"]]$COMP_ID
PM10_comorb_met<-sig_LC_results_morb[["PM10_exp_LC_met"]]$COMP_ID
PM25_comorb_met<-sig_LC_results_morb[["PM25_exp_LC_met"]]$COMP_ID
SO2_comorb_met<-sig_LC_results_morb[["SO2_exp_LC_met"]]$COMP_ID

morb_filter_id<-list(
  CO_exp_LC_met = CO_comorb_met,
  NO2_exp_LC_met = NO2_comorb_met,
  O3_exp_LC_met = O3_comorb_met,
  PM10_exp_LC_met = PM10_comorb_met,
  PM25_exp_LC_met = PM25_comorb_met,
  SO2_exp_LC_met = SO2_comorb_met
)

comorb_filtered_list <- mapply(function(df, ids) {
  df[df$COMP_ID %in% ids, ]
}, morb_results[names(morb_filter_id)], morb_filter_id, SIMPLIFY = FALSE)

library(openxlsx)
wb<-createWorkbook()
addWorksheet(wb, "CO", tabColour = "black")
addWorksheet(wb, "NO2", tabColour = "black")
addWorksheet(wb, "O3", tabColour = "black")
addWorksheet(wb, "PM10", tabColour = "black")
addWorksheet(wb, "PM25", tabColour = "black")
addWorksheet(wb, "SO2", tabColour = "black")
writeData(wb, "CO", comorb_filtered_list[["CO_exp_LC_met"]], rowNames=T, colNames=T)
writeData(wb, "NO2", comorb_filtered_list[["NO2_exp_LC_met"]], rowNames=T, colNames=T)
writeData(wb, "O3", comorb_filtered_list[["O3_exp_LC_met"]], rowNames=T, colNames=T)
writeData(wb, "PM10", comorb_filtered_list[["PM10_exp_LC_met"]], rowNames=T, colNames=T)
writeData(wb, "PM25", comorb_filtered_list[["PM25_exp_LC_met"]], rowNames=T, colNames=T)
writeData(wb, "SO2", comorb_filtered_list[["SO2_exp_LC_met"]], rowNames=T, colNames=T)
saveWorkbook(wb, file="Comorb.xlsx", overwrite=TRUE)

################################
###Sensitivity Analyses#########
###No-comorbidities###########
################################
dtscaled_nomorb<-dtscaled_morb1[dtscaled_morb1$HCOMORB == 0, ]
# Initialize list to store result dataframes and MWAS summary
no_morb_results1 <- list()

# Loop through each pollutant
for (exposure in exposures) {
  
  # Create empty dataframe to hold regression results
  temp_result <- data.frame(matrix(nrow = 8, ncol = 6))
  colnames(temp_result) <- c("Est", "Std", "t-value", "P", "LowerCI", "UpperCI")
  
  for (i in 1:8) {
    tryCatch({
      formula <- as.formula(
        paste0("dtscaled_nomorb[, i + 19] ~ ", exposure, " + BMI + AgeBloodDraw + SEX + RACE + ",
               "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
               "factor(ALC) + factor(Smokegroup1) + factor(PASSIVESMOKER)")
      )
      lmfit <- lm(formula, data = dtscaled_nomorb)
      coefs <- summary(lmfit)$coefficients[2, ]
      ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
      temp_result[i, ] <- c(coefs, ci)
    }, error = function(e) {})
  }
  
  # Adjust p-values and attach compound ID
  temp_result$pfdr <- p.adjust(temp_result$P, method = "BH")
  temp_result_met <- cbind(colnames(dtscaled_nomorb)[20:ncol(dtscaled_nomorb)], temp_result)
  colnames(temp_result_met)[1] <- "COMP_ID"
  
  # Store the result in a named list
  result_name <- paste0("dtscaled_nomorb_", exposure, "_met")
  no_morb_results1[[result_name]] <- temp_result_met
  
  # Store summary statistics
  MWASStat1[kk, ] <- c(
    result_name,
    sum(temp_result_met$P < 0.05, na.rm = TRUE),
    sum(temp_result_met$P < 0.01, na.rm = TRUE),
    sum(temp_result_met$P < 0.005, na.rm = TRUE),
    sum(temp_result_met$P < 0.0005, na.rm = TRUE),
    sum(temp_result_met$pfdr < 0.20, na.rm = TRUE),
    sum(temp_result_met$pfdr < 0.05, na.rm = TRUE)
  )
  
  kk <- kk + 1
}

####LC Analysis
for (exposure in exposures) {
  
  
  LC_result <- data.frame(matrix(nrow = 8, ncol = 6))
  colnames(LC_result) <- c("Est", "Std", "t-value", "P", "LowerCI", "UpperCI")
  
  for (i in 1:8) {
    tryCatch({
      formula <- as.formula(
        paste0("dtscaled_nomorb[, i + 19] ~ factor(CACO.x) + BMI + AgeBloodDraw + SEX + RACE + ",
               "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
               "factor(ALC) + factor(Smokegroup1) + factor(PASSIVESMOKER)")
      )
      lmfit <- lm(formula, data = dtscaled_nomorb)
      coefs <- summary(lmfit)$coefficients[2, ]
      ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
      LC_result[i, ] <- c(coefs, ci)
    }, error = function(e) {})
  }
  
  # Adjust p-values and attach compound ID
  LC_result$pfdr <- p.adjust(temp_result$P, method = "BH")
  LC_result <- cbind(colnames(dtscaled_nomorb)[20:ncol(dtscaled_nomorb)], LC_result)
  colnames(LC_result)[1] <- "COMP_ID"
  
  # Store the result in a named list
  result_name <- paste0("LC_morb", exposure, "_met")
  no_morb_results1[[result_name]] <- LC_result
  
  
  # Store MWAS summary for LC
  MWASStat1[kk, ] <- c(
    paste0(exposure, "_LC_met_fiveyr"),
    sum(LC_met$P < 0.05, na.rm = TRUE),
    sum(LC_met$P < 0.01, na.rm = TRUE),
    sum(LC_met$P < 0.005, na.rm = TRUE),
    sum(LC_met$P < 0.0005, na.rm = TRUE),
    sum(LC_met$pfdr < 0.20, na.rm = TRUE),
    sum(LC_met$pfdr < 0.05, na.rm = TRUE)
  )
  
  kk <- kk + 1
}


write.csv(no_morb_results1[["dtscaled_nomorb_CO_exp_met"]], file = "CO_exp.csv")
write.csv(no_morb_results1[["dtscaled_nomorb_NO2_exp_met"]], file = "NO2_exp.csv")
write.csv(no_morb_results1[["dtscaled_nomorb_O3_exp_met"]], file = "O3_exp.csv")
write.csv(no_morb_results1[["dtscaled_nomorb_PM10_exp_met"]], file = "PM10_exp.csv")
write.csv(no_morb_results1[["dtscaled_nomorb_PM25_exp_met"]], file = "PM25_exp.csv")
write.csv(no_morb_results1[["dtscaled_nomorb_SO2_exp_met"]], file = "SO2_exp.csv")
write.csv(no_morb_results1[["LC_morbCO_exp_met"]], file = "LC_CO.csv")
write.csv(no_morb_results1[["LC_morbNO2_exp_met"]], file = "LC_NO2.csv")
write.csv(no_morb_results1[["LC_morbO3_exp_met"]], file = "LC_O3.csv")
write.csv(no_morb_results1[["LC_morbPM10_exp_met"]], file = "LC_PM10.csv")
write.csv(no_morb_results1[["LC_morbPM25_exp_met"]], file = "LC_PM25.csv")
write.csv(no_morb_results1[["LC_morbSO2_exp_met"]], file = "LC_SO2.csv")


################################
###Sensitivity Analyses#########
###Family History#####
################################
fam_hist<-list()

# Loop through each pollutant
for (exposure in exposures) {
  
  # Create empty dataframe to hold regression results
  temp_result <- data.frame(matrix(nrow = (nrow(biochem.blood) - length(removemet)), ncol = 4))
  colnames(temp_result) <- c("Est", "Std", "t-value", "P")
  
  for (i in 1:(nrow(biochem.blood) - length(removemet))) {
    tryCatch({
      formula <- as.formula(
        paste0("dtscaled[, i + 480] ~ ", exposure, " + BMI + AgeBloodDraw + SEX + RACE + ",
               "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
               "factor(ALC) + factor(Smokegroup1) + factor(PASSIVESMOKER) + factor(FAMHXLG)")
      )
      lmfit <- lm(formula, data = dtscaled)
      temp_result[i, ] <- summary(lmfit)$coefficients[2, ]
    }, error = function(e) {})
  }
  
  # Adjust p-values and attach compound ID
  temp_result$pfdr <- p.adjust(temp_result$P, method = "BH")
  temp_result_met <- cbind(colnames(dtscaled)[481:ncol(dtscaled)], temp_result)
  colnames(temp_result_met)[1] <- "COMP_ID"
  
  # Store the result in a named list
  result_name <- paste0("dtscaled_", exposure, "_met")
  fam_hist[[result_name]] <- temp_result_met
  
  # Store summary statistics
  MWASStat1[kk, ] <- c(
    result_name,
    sum(temp_result_met$P < 0.05, na.rm = TRUE),
    sum(temp_result_met$P < 0.01, na.rm = TRUE),
    sum(temp_result_met$P < 0.005, na.rm = TRUE),
    sum(temp_result_met$P < 0.0005, na.rm = TRUE),
    sum(temp_result_met$pfdr < 0.20, na.rm = TRUE),
    sum(temp_result_met$pfdr < 0.05, na.rm = TRUE)
  )
  
  kk <- kk + 1
}

####LC Analysis
for (exposure in exposures) {
  
  # Retrieve first-stage result
  result_name <- paste0("dtscaled_", exposure, "_met")
  res_df <- main_results[[result_name]]
  
  # Filter for significant metabolites
  sig_met <- subset(res_df, pfdr < 0.2 & !is.na(pfdr))
  
  if (nrow(sig_met) == 0) {
    # Skip if no significant metabolites
    next
  }
  
  # Build variable list
  met_names <- sig_met$COMP_ID
  var_list <- c(exposure, "AgeBloodDraw", "SEX", "RACE", "BMI", "EDUCGRP", "MVUSE",
                "FV_UPDATED", "ALC", "Smokegroup1", "PASSIVESMOKER", "FAMHXLG", "CACO.x", met_names)
  
  # Subset the data
  data_subset <- dtscaled[, var_list]
  
  # Prepare result dataframes
  n_met <- length(met_names)
  LC_df <- data.frame(matrix(nrow = n_met, ncol = 4))
  colnames(LC_df) <- c("Est", "Std", "t-value", "P")
  
  LC_confint <- data.frame(matrix(nrow = n_met, ncol = 2))
  colnames(LC_confint) <- c("Lower", "Upper")
  
  # Run linear models
  for (i in 1:n_met) {
    tryCatch({
      formula <- as.formula(
        paste0("data_subset[, i + 12] ~ factor(CACO.x) + BMI + AgeBloodDraw + SEX + RACE + ",
               "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
               "factor(ALC) + factor(Smokegroup1) + factor(PASSIVESMOKER) + factor(FAMHXLG)")
      )
      lmfit <- lm(formula, data = data_subset)
      coef_vals <- summary(lmfit)$coefficients[2, ]
      LC_df[i, ] <- coef_vals
      
      conf_vals <- confint(lmfit)[2, ]
      LC_confint[i, ] <- conf_vals
    }, error = function(e) {})
  }
  
  # Adjust p-values
  LC_df$pfdr <- p.adjust(LC_df$P, method = "BH")
  
  # Combine all results
  LC_met <- cbind(met_names, LC_df, LC_confint)
  colnames(LC_met)[1] <- "COMP_ID"
  
  # Store the final LC result
  fam_hist[[paste0(exposure, "_LC_met")]] <- LC_met
  
  # Store MWAS summary for LC
  MWASStat1[kk, ] <- c(
    paste0(exposure, "_LC_met"),
    sum(LC_met$P < 0.05, na.rm = TRUE),
    sum(LC_met$P < 0.01, na.rm = TRUE),
    sum(LC_met$P < 0.005, na.rm = TRUE),
    sum(LC_met$P < 0.0005, na.rm = TRUE),
    sum(LC_met$pfdr < 0.20, na.rm = TRUE),
    sum(LC_met$pfdr < 0.05, na.rm = TRUE)
  )
  
  kk <- kk + 1
}

fam_hist_sig_LC_results <- lapply(fam_hist, function(df) {
  subset(df, pfdr < 0.2 & !is.na(pfdr))
})

fam_hist_sig_LC_results[["CO_exp_LC_met"]]<-merge(fam_hist_sig_LC_results[["CO_exp_LC_met"]], biochem.blood, by = "COMP_ID")
fam_hist_sig_LC_results[["NO2_exp_LC_met"]]<-merge(fam_hist_sig_LC_results[["NO2_exp_LC_met"]], biochem.blood, by = "COMP_ID")
fam_hist_sig_LC_results[["O3_exp_LC_met"]]<-merge(fam_hist_sig_LC_results[["O3_exp_LC_met"]], biochem.blood, by = "COMP_ID")
fam_hist_sig_LC_results[["PM10_exp_LC_met"]]<-merge(fam_hist_sig_LC_results[["PM10_exp_LC_met"]], biochem.blood, by = "COMP_ID")
fam_hist_sig_LC_results[["PM25_exp_LC_met"]]<-merge(fam_hist_sig_LC_results[["PM25_exp_LC_met"]], biochem.blood, by = "COMP_ID")
fam_hist_sig_LC_results[["SO2_exp_LC_met"]]<-merge(fam_hist_sig_LC_results[["SO2_exp_LC_met"]], biochem.blood, by = "COMP_ID")

write.csv(fam_hist_sig_LC_results[["CO_exp_LC_met"]], file = "CO_fam.csv")
write.csv(fam_hist_sig_LC_results[["NO2_exp_LC_met"]], file = "NO2_fam.csv")
write.csv(fam_hist_sig_LC_results[["O3_exp_LC_met"]], file = "O3_fam.csv")
write.csv(fam_hist_sig_LC_results[["PM10_exp_LC_met"]], file = "PM10_fam.csv")
write.csv(fam_hist_sig_LC_results[["PM25_exp_LC_met"]], file = "PM25_fam.csv")
write.csv(fam_hist_sig_LC_results[["SO2_exp_LC_met"]], file = "SO2_fam.csv")

###pull the AP data
CO_famhx_met<-fam_hist_sig_LC_results[["CO_exp_LC_met"]]$COMP_ID
NO2_famhx_met<-fam_hist_sig_LC_results[["NO2_exp_LC_met"]]$COMP_ID
PM10_famhx_met<-fam_hist_sig_LC_results[["PM10_exp_LC_met"]]$COMP_ID
PM25_famhx_met<-fam_hist_sig_LC_results[["PM25_exp_LC_met"]]$COMP_ID
SO2_famhx_met<-fam_hist_sig_LC_results[["SO2_exp_LC_met"]]$COMP_ID

famhx_filter_id<-list(
  CO_exp_LC_met = CO_famhx_met,
  NO2_exp_LC_met = NO2_famhx_met,
  PM10_exp_LC_met = PM10_famhx_met,
  PM25_exp_LC_met = PM25_famhx_met,
  SO2_exp_LC_met = SO2_famhx_met
)

famhx_filtered_list <- mapply(function(df, ids) {
  df[df$COMP_ID %in% ids, ]
}, fam_hist[names(famhx_filter_id)], famhx_filter_id, SIMPLIFY = FALSE)

library(openxlsx)
wb<-createWorkbook()
addWorksheet(wb, "CO", tabColour = "black")
addWorksheet(wb, "NO2", tabColour = "black")
addWorksheet(wb, "PM10", tabColour = "black")
addWorksheet(wb, "PM25", tabColour = "black")
writeData(wb, "CO", famhx_filtered_list[["CO_exp_LC_met"]], rowNames=T, colNames=T)
writeData(wb, "NO2", famhx_filtered_list[["NO2_exp_LC_met"]], rowNames=T, colNames=T)
writeData(wb, "PM10", famhx_filtered_list[["PM10_exp_LC_met"]], rowNames=T, colNames=T)
writeData(wb, "PM25", famhx_filtered_list[["PM25_exp_LC_met"]], rowNames=T, colNames=T)
saveWorkbook(wb, file="famhx.xlsx", overwrite=TRUE)


