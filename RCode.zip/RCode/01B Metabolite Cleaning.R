library(RFmarkerDetector)

####METABOLITE DATA CLEANING####

##Pull metabolite data
mraw<-finalData$origMet
mscaled<-finalData$batchNorm
biochem.blood<-finalData$annotation

mrawlog<-as.data.frame(mraw[,1])
colnames(mrawlog) <- "ID"
mscalelog <-as.data.frame(mscaled[,1])
colnames(mscalelog) <- "ID"

###Natural log transform and auto scale 
mrawlog[,2:1402]<-log(mraw[,2:1402])
mrawlog[,2:1402]<-autoscale(mrawlog[,2:1402],exclude=F)
mscalelog[,2:1402] <- log(mscaled[,2:1402])
mscalelog[,2:1402] <- autoscale(mscalelog[,2:1402],exclude=F)

mrawlog <- impute(mrawlog, fun = min)
mscalelog = impute(mscalelog, fun = min)

##Match datasets
total<-subset(total, select = -c(MATCHID.x, Cohort.x))

dtrawl_tem<-left_join(total,mrawlog,by="ID")
dtscaled_tem<-left_join(total,mscalelog,by="ID")

colnames(dtrawl_tem[,1:100])
colnames(dtscaled_tem[,1:100])
colnames(dtrawl_tem[,101:120])
colnames(dtscaled_tem[,101:120])

##Get rid of duplicates
dtrawl <- dtrawl_tem[!duplicated(dtrawl_tem$ID),]
dtscaled<- dtscaled_tem[!duplicated(dtscaled_tem$ID),]

##Remove ICC < 0.5
ICC_remove<-biochem.blood$ICC_TECH[biochem.blood$ICC_TECH<=0.5]
ICC_removeID<-biochem.blood$COMP_ID[biochem.blood$ICC_TECH %in% ICC_remove]


dtrawl<-dtrawl[,!colnames(dtrawl) %in% ICC_removeID]
dtscaled<-dtscaled[,!colnames(dtscaled) %in% ICC_removeID]
biochem.blood<-biochem.blood[!biochem.blood$COMP_ID %in% ICC_removeID,]



###QAQC
##dtrawl
mqaqcrawl<-data.frame(matrix(nrow = 1138, ncol = 2))
colnames(mqaqcrawl)<-c("feature","pntNA")
for (i in 1:1138)
{
  mqaqcrawl$feature[i]<-colnames(dtrawl[479+i]) ##479 is the column before the metabolites start
  mqaqcrawl$pntNA[i]<-sum(is.na(dtrawl[,479+i]))/1359*100   
}

##dtscaled
mqaqcscaled<-data.frame(matrix(nrow = 1138, ncol = 2))
colnames(mqaqcscaled)<-c("feature","pntNA")
for (i in 1:1138)
{
  mqaqcscaled$feature[i]<-colnames(dtscaled[479+i])
  mqaqcscaled$pntNA[i]<-sum(is.na(dtscaled[,479+i]))/1359*100
}

hist(mqaqcrawl$pntNA)
table(mqaqcrawl$pntNA > 90)
hist(mqaqcscaled$pntNA)
table(mqaqcscaled$pntNA > 90)

mqaqccom <- merge(mqaqcrawl,mqaqcscaled,by="feature",all=TRUE, sort=FALSE)

identical(mqaqccom$feature,colnames(dtscaled[,480:1617]))


removeval <-data.frame(matrix(nrow = 1138, ncol = 1))
for (i in 1:1138)
{
  if (is.na(mqaqccom$pntNA.x[i])) {
    removeval[i,1] <- mqaqccom$feature[i] 
  } else {
    if(mqaqccom$pntNA.x[i] > 90) {
      removeval[i,1] <- mqaqccom$feature[i] 
    }
  }
}

table(is.na(removeval))
removemet <- removeval[!is.na(removeval), 1]
dtscaled <- dtscaled[,!colnames(dtscaled) %in% removemet]

dim(dtscaled)
#1359 1617 <-should be this
