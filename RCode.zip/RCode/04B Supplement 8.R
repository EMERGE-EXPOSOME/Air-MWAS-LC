sig_met<-c("X61771", "X48442", "X32412", "X2730", "X44872", "X31536", "X52925", "X49531")

var_list<-c(exposures, "AgeBloodDraw", "SEX", "RACE", "BMI", "EDUCGRP", "MVUSE",
  "FV_UPDATED", "ALC", "Smokegroup1", "PASSIVESMOKER", "FAMHXLG", "CACO.x", sig_met)

dtscaled_sig<-subset(dtscaled, select = var_list)

stratas<-list(
  "sex_female" = dtscaled[dtscaled$SEX == "Female", ],
  "sex_male" = dtscaled[dtscaled$SEX == "Male", ],
  "smoker_ever" = dtscaled[dtscaled$Smokegroup1 == "Current" | dtscaled$Smokegroup1 == "Former", ],
  "smoker_never" = dtscaled[dtscaled$Smokegroup1 == "Never", ],
  "famxl_no" = dtscaled[dtscaled$FAMHXLG == "No", ],
  "famxl_yes" = dtscaled[dtscaled$FAMHXLG == "Yes", ],
  "age_up" = dtscaled[dtscaled$AgeBloodDraw >= 65, ],
  "age_down" = dtscaled[dtscaled$AgeBloodDraw < 65, ],
  "age_older" = dtscaled[dtscaled$AgeBloodDraw > 55, ],
  "age_younger" = dtscaled[dtscaled$AgeBloodDraw <= 55,]
)




#metabolites = sig_met
#pollutants = pllutants
#strata = strata

pollutants<-c("CO_exp", "NO2_exp", "O3_exp", "PM10_exp", "PM25_exp", "SO2_exp")


i <- 1

####Results for 2-furoylcaritine (COMP_ID = X61771)
furoyl_results<-list()
for (pollutant in pollutants) {
  for (strata in names(stratas)) {
    
    data_subset <- stratas[[strata]]
    
    formula <- as.formula(
      paste0(" X61771 ~ ", pollutant, " + BMI + AgeBloodDraw + RACE + ",
             "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
             "factor(ALC) + factor(PASSIVESMOKER)"))
    
    lmfit <- lm(formula, data = data_subset)
    coefs <- summary(lmfit)$coefficients[2, ]
    ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
    model_name<-paste(pollutant, strata, sep = "_")
    
    results_row<-data.frame(
      Model = model_name,
      Estimate = coefs["Estimate"],
      Std = coefs["Std. Error"],
      t_val = coefs["t value"],
      p_val = coefs["Pr(>|t|)"],
      CI_lower = ci[1],
      CI_upper = ci[2],
      stringsAsFactors = FALSE
    )
    
    furoyl_results[[i]] <- results_row
    i<-i+1
  
  }
}

furoyl_table <- do.call(rbind, furoyl_results)

####Results for 4-vinylguaiacol sulfate (COMP_ID = X48442)
vinyl_results<-list()
for (pollutant in pollutants) {
  for (strata in names(stratas)) {
    
    data_subset <- stratas[[strata]]
    
    formula <- as.formula(
      paste0(" X48442 ~ ", pollutant, " + BMI + AgeBloodDraw + RACE + ",
             "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
             "factor(ALC) + factor(PASSIVESMOKER)"))
    
    lmfit <- lm(formula, data = data_subset)
    coefs <- summary(lmfit)$coefficients[2, ]
    ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
    model_name<-paste(pollutant, strata, sep = "_")
    
    results_row<-data.frame(
      Model = model_name,
      Estimate = coefs["Estimate"],
      Std = coefs["Std. Error"],
      t_val = coefs["t value"],
      p_val = coefs["Pr(>|t|)"],
      CI_lower = ci[1],
      CI_upper = ci[2],
      stringsAsFactors = FALSE
    )
    
    vinyl_results[[i]] <- results_row
    i<-i+1
    
  }
}

vinyl_table <- do.call(rbind, vinyl_results)

####Results for butyrylcartitine (C4) (COMP_ID = X32412)
butyryl_results<-list()
for (pollutant in pollutants) {
  for (strata in names(stratas)) {
    
    data_subset <- stratas[[strata]]
    
    formula <- as.formula(
      paste0(" X32412 ~ ", pollutant, " + BMI + AgeBloodDraw + RACE + ",
             "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
             "factor(ALC) + factor(PASSIVESMOKER)"))
    
    lmfit <- lm(formula, data = data_subset)
    coefs <- summary(lmfit)$coefficients[2, ]
    ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
    model_name<-paste(pollutant, strata, sep = "_")
    
    results_row<-data.frame(
      Model = model_name,
      Estimate = coefs["Estimate"],
      Std = coefs["Std. Error"],
      t_val = coefs["t value"],
      p_val = coefs["Pr(>|t|)"],
      CI_lower = ci[1],
      CI_upper = ci[2],
      stringsAsFactors = FALSE
    )
    
    butyryl_results[[i]] <- results_row
    i<-i+1
    
  }
}

butyryl_table <- do.call(rbind, butyryl_results)

####Results for gamma-glutamylglutamine (COMP_ID = X2730)
ggglut_results<-list()
for (pollutant in pollutants) {
  for (strata in names(stratas)) {
    
    data_subset <- stratas[[strata]]
    
    formula <- as.formula(
      paste0(" X2730 ~ ", pollutant, " + BMI + AgeBloodDraw + RACE + ",
             "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
             "factor(ALC) + factor(PASSIVESMOKER)"))
    
    lmfit <- lm(formula, data = data_subset)
    coefs <- summary(lmfit)$coefficients[2, ]
    ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
    model_name<-paste(pollutant, strata, sep = "_")
    
    results_row<-data.frame(
      Model = model_name,
      Estimate = coefs["Estimate"],
      Std = coefs["Std. Error"],
      t_val = coefs["t value"],
      p_val = coefs["Pr(>|t|)"],
      CI_lower = ci[1],
      CI_upper = ci[2],
      stringsAsFactors = FALSE
    )
    
    ggglut_results[[i]] <- results_row
    i<-i+1
    
  }
}

ggglut_table <- do.call(rbind, ggglut_results)

####Results for gamma-glutamylmethionine (COMP_ID = X44872)
ggmeth_results<-list()
for (pollutant in pollutants) {
  for (strata in names(stratas)) {
    
    data_subset <- stratas[[strata]]
    
    formula <- as.formula(
      paste0(" X44872 ~ ", pollutant, " + BMI + AgeBloodDraw + RACE + ",
             "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
             "factor(ALC) + factor(PASSIVESMOKER)"))
    
    lmfit <- lm(formula, data = data_subset)
    coefs <- summary(lmfit)$coefficients[2, ]
    ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
    model_name<-paste(pollutant, strata, sep = "_")
    
    results_row<-data.frame(
      Model = model_name,
      Estimate = coefs["Estimate"],
      Std = coefs["Std. Error"],
      t_val = coefs["t value"],
      p_val = coefs["Pr(>|t|)"],
      CI_lower = ci[1],
      CI_upper = ci[2],
      stringsAsFactors = FALSE
    )
    
    ggmeth_results[[i]] <- results_row
    i<-i+1
    
  }
}

ggmeth_table <- do.call(rbind, ggmeth_results)

####Results for N-(2-furoyl)glycine (COMP_ID = X31536)
glycine_results<-list()
for (pollutant in pollutants) {
  for (strata in names(stratas)) {
    
    data_subset <- stratas[[strata]]
    
    formula <- as.formula(
      paste0(" X31536 ~ ", pollutant, " + BMI + AgeBloodDraw + RACE + ",
             "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
             "factor(ALC) + factor(PASSIVESMOKER)"))
    
    lmfit <- lm(formula, data = data_subset)
    coefs <- summary(lmfit)$coefficients[2, ]
    ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
    model_name<-paste(pollutant, strata, sep = "_")
    
    results_row<-data.frame(
      Model = model_name,
      Estimate = coefs["Estimate"],
      Std = coefs["Std. Error"],
      t_val = coefs["t value"],
      p_val = coefs["Pr(>|t|)"],
      CI_lower = ci[1],
      CI_upper = ci[2],
      stringsAsFactors = FALSE
    )
    
    glycine_results[[i]] <- results_row
    i<-i+1
    
  }
}

glycine_table <- do.call(rbind, glycine_results)


####Results for phenylacetylglutamate (COMP_ID = X52925)
phenyl_results<-list()
for (pollutant in pollutants) {
  for (strata in names(stratas)) {
    
    data_subset <- stratas[[strata]]
    
    formula <- as.formula(
      paste0(" X52925 ~ ", pollutant, " + BMI + AgeBloodDraw + RACE + ",
             "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
             "factor(ALC) + factor(PASSIVESMOKER)"))
    
    lmfit <- lm(formula, data = data_subset)
    coefs <- summary(lmfit)$coefficients[2, ]
    ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
    model_name<-paste(pollutant, strata, sep = "_")
    
    results_row<-data.frame(
      Model = model_name,
      Estimate = coefs["Estimate"],
      Std = coefs["Std. Error"],
      t_val = coefs["t value"],
      p_val = coefs["Pr(>|t|)"],
      CI_lower = ci[1],
      CI_upper = ci[2],
      stringsAsFactors = FALSE
    )
    
    phenyl_results[[i]] <- results_row
    i<-i+1
    
  }
}

phenyl_table <- do.call(rbind, phenyl_results)


death_table<-list(furoyl_table, vinyl_table, butyryl_table, ggglut_table, ggmeth_table, glycine_table, phenyl_table)

library(openxlsx)
wb<-createWorkbook()
addWorksheet(wb, "furoyl", tabColour = "black")
addWorksheet(wb, "vinyl", tabColour = "black")
addWorksheet(wb, "butyryl", tabColour = "black")
addWorksheet(wb, "ggglut", tabColour = "black")
addWorksheet(wb, "ggmeth", tabColour = "black")
addWorksheet(wb, "glycine", tabColour = "black")
addWorksheet(wb, "phenyl", tabColour = "black")
writeData(wb, "furoyl", furoyl_table, rowNames=T, colNames=T)
writeData(wb, "vinyl", vinyl_table, rowNames=T, colNames=T)
writeData(wb, "butyryl", butyryl_table, rowNames=T, colNames=T)
writeData(wb, "ggglut", ggglut_table, rowNames=T, colNames=T)
writeData(wb, "ggmeth", ggmeth_table, rowNames=T, colNames=T)
writeData(wb, "glycine", glycine_table, rowNames=T, colNames=T)
writeData(wb, "phenyl", phenyl_table, rowNames=T, colNames=T)
saveWorkbook(wb, file="Death Table1.xlsx", overwrite=TRUE)

########################################3
####Cancer Results############
##############################

cancer_results<-list()
####Results for 2-furoylcaritine (COMP_ID = X61771)
for (strata in names(stratas)) {
  
  data_subset <- stratas[[strata]]
  
  formula <- as.formula(
    paste0(" X61771 ~ factor(CACO.x) + BMI + AgeBloodDraw + RACE + ",
           "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
           "factor(ALC) + factor(PASSIVESMOKER)"))
  
  lmfit <- lm(formula, data = data_subset)
  coefs <- summary(lmfit)$coefficients[2, ]
  ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
  model_name<-paste("furoyl", strata, sep = "_")
  
  results_row<-data.frame(
    Model = model_name,
    Estimate = coefs["Estimate"],
    Std = coefs["Std. Error"],
    t_val = coefs["t value"],
    p_val = coefs["Pr(>|t|)"],
    CI_lower = ci[1],
    CI_upper = ci[2],
    stringsAsFactors = FALSE
  )
  
  cancer_results[[i]] <- results_row
  i<-i+1
  
}

####Results for 4-vinylguaiacol sulfate (COMP_ID = X48442)
for (strata in names(stratas)) {
  
  data_subset <- stratas[[strata]]
  
  formula <- as.formula(
    paste0(" X48442 ~ factor(CACO.x) + BMI + AgeBloodDraw + RACE + ",
           "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
           "factor(ALC) + factor(PASSIVESMOKER)"))
  
  lmfit <- lm(formula, data = data_subset)
  coefs <- summary(lmfit)$coefficients[2, ]
  ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
  model_name<-paste("vinyl", strata, sep = "_")
  
  results_row<-data.frame(
    Model = model_name,
    Estimate = coefs["Estimate"],
    Std = coefs["Std. Error"],
    t_val = coefs["t value"],
    p_val = coefs["Pr(>|t|)"],
    CI_lower = ci[1],
    CI_upper = ci[2],
    stringsAsFactors = FALSE
  )
  
  cancer_results[[i]] <- results_row
  i<-i+1
  
}

####Results for butyrylcartitine (C4) (COMP_ID = X32412)
for (strata in names(stratas)) {
  
  data_subset <- stratas[[strata]]
  
  formula <- as.formula(
    paste0(" X32412 ~ factor(CACO.x) + BMI + AgeBloodDraw + RACE + ",
           "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
           "factor(ALC) + factor(PASSIVESMOKER)"))
  
  lmfit <- lm(formula, data = data_subset)
  coefs <- summary(lmfit)$coefficients[2, ]
  ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
  model_name<-paste("butyryl", strata, sep = "_")
  
  results_row<-data.frame(
    Model = model_name,
    Estimate = coefs["Estimate"],
    Std = coefs["Std. Error"],
    t_val = coefs["t value"],
    p_val = coefs["Pr(>|t|)"],
    CI_lower = ci[1],
    CI_upper = ci[2],
    stringsAsFactors = FALSE
  )
  
  cancer_results[[i]] <- results_row
  i<-i+1
  
}

####Results for gamma-glutamylglutamine (COMP_ID = X2730)
for (strata in names(stratas)) {
  
  data_subset <- stratas[[strata]]
  
  formula <- as.formula(
    paste0(" X2730 ~ factor(CACO.x) + BMI + AgeBloodDraw + RACE + ",
           "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
           "factor(ALC) + factor(PASSIVESMOKER)"))
  
  lmfit <- lm(formula, data = data_subset)
  coefs <- summary(lmfit)$coefficients[2, ]
  ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
  model_name<-paste("ggglut", strata, sep = "_")
  
  results_row<-data.frame(
    Model = model_name,
    Estimate = coefs["Estimate"],
    Std = coefs["Std. Error"],
    t_val = coefs["t value"],
    p_val = coefs["Pr(>|t|)"],
    CI_lower = ci[1],
    CI_upper = ci[2],
    stringsAsFactors = FALSE
  )
  
  cancer_results[[i]] <- results_row
  i<-i+1
  
}

####Results for gamma-glutamylmethionine (COMP_ID = X44872)
for (strata in names(stratas)) {
  
  data_subset <- stratas[[strata]]
  
  formula <- as.formula(
    paste0(" X44872 ~ factor(CACO.x) + BMI + AgeBloodDraw + RACE + ",
           "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
           "factor(ALC) + factor(PASSIVESMOKER)"))
  
  lmfit <- lm(formula, data = data_subset)
  coefs <- summary(lmfit)$coefficients[2, ]
  ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
  model_name<-paste("ggmeth", strata, sep = "_")
  
  results_row<-data.frame(
    Model = model_name,
    Estimate = coefs["Estimate"],
    Std = coefs["Std. Error"],
    t_val = coefs["t value"],
    p_val = coefs["Pr(>|t|)"],
    CI_lower = ci[1],
    CI_upper = ci[2],
    stringsAsFactors = FALSE
  )
  
  cancer_results[[i]] <- results_row
  i<-i+1
  
}

####Results for N-(2-furoyl)glycine (COMP_ID = X31536)
for (strata in names(stratas)) {
  
  data_subset <- stratas[[strata]]
  
  formula <- as.formula(
    paste0(" X31536 ~ factor(CACO.x) + BMI + AgeBloodDraw + RACE + ",
           "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
           "factor(ALC) + factor(PASSIVESMOKER)"))
  
  lmfit <- lm(formula, data = data_subset)
  coefs <- summary(lmfit)$coefficients[2, ]
  ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
  model_name<-paste("glycine", strata, sep = "_")
  
  results_row<-data.frame(
    Model = model_name,
    Estimate = coefs["Estimate"],
    Std = coefs["Std. Error"],
    t_val = coefs["t value"],
    p_val = coefs["Pr(>|t|)"],
    CI_lower = ci[1],
    CI_upper = ci[2],
    stringsAsFactors = FALSE
  )
  
  cancer_results[[i]] <- results_row
  i<-i+1
  
}

####Results for phenylacetylglutamate (COMP_ID = X52925)
for (strata in names(stratas)) {
  
  data_subset <- stratas[[strata]]
  
  formula <- as.formula(
    paste0(" X52925 ~ factor(CACO.x) + BMI + AgeBloodDraw + RACE + ",
           "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
           "factor(ALC) + factor(PASSIVESMOKER)"))
  
  lmfit <- lm(formula, data = data_subset)
  coefs <- summary(lmfit)$coefficients[2, ]
  ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
  model_name<-paste("phenyl", strata, sep = "_")
  
  results_row<-data.frame(
    Model = model_name,
    Estimate = coefs["Estimate"],
    Std = coefs["Std. Error"],
    t_val = coefs["t value"],
    p_val = coefs["Pr(>|t|)"],
    CI_lower = ci[1],
    CI_upper = ci[2],
    stringsAsFactors = FALSE
  )
  
  cancer_results[[i]] <- results_row
  i<-i+1
  
}



##Merge Table Together
cancer_table <- do.call(rbind, cancer_results)
write.csv(cancer_table, "cancer_table.csv")
