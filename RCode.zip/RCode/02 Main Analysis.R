##Remove the two old cases
id<-fruit$ID[fruit$OLD_CASE == 1]
dtscaled<-filter(dtscaled, !(dtscaled$ID %in% id))


##Define all the exposures
exposures <- c("CO_exp", "NO2_exp", "O3_exp", "PM10_exp", "PM25_exp", "SO2_exp")

MWASStat1 <- matrix(nrow = 1000, ncol = 7)
colnames(MWASStat1) <- c("Model", "P<0.05", "P<0.01", "P<0.005", "P<0.0005", "FDR<0.20", "FDR<0.05")
kk <- 1

#################
###MAIN RESULTS##
#################
# Initialize list to store result dataframes and MWAS summary
main_results <- list()

# Loop through each pollutant
for (exposure in exposures) {
  
  # Create empty dataframe to hold regression results
  temp_result <- data.frame(matrix(nrow = (nrow(biochem.blood) - length(removemet)), ncol = 6))
  colnames(temp_result) <- c("Est", "Std", "t-value", "P", "Lower_CI", "Upper_CI")
  
  temp_result_iqr <- data.frame(matrix(nrow = (nrow(biochem.blood) - length(removemet)), ncol = 3))
  colnames(temp_iqr) <- c("IQR Est", "IQR Lower", "IQR Upper")
  
  exposure_IQR <- IQR(dtscaled[[exposure]], na.rm = TRUE)
  
  for (i in 1:(nrow(biochem.blood) - length(removemet))) {
    tryCatch({
      formula <- as.formula(
        paste0("dtscaled[, i + 480] ~ ", exposure, " + BMI + AgeBloodDraw + SEX + RACE + ",
               "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
               "factor(ALC) + factor(Smokegroup1) + factor(PASSIVESMOKER)")
      )
      lmfit <- lm(formula, data = dtscaled)
      coefs <- summary(lmfit)$coefficients[2, ]
      ci <- confint(lmfit)[2, ]  # 95% CI for the exposure variable
      temp_result[i, ] <- c(coefs, ci)
      
      raw_beta <- summary(lmfit)$coefficients[2, 1]
      temp_result_iqr[i, "IQR Est"] <- raw_beta * exposure_IQR
      temp_result_iqr[i, "IQR Lower"] <- confint(lmfit)[2,1] * exposure_IQR
      temp_result_iqr[i, "IQR Upper"] <- confint(lmfit)[2,2] * exposure_IQR
      
      

    }, error = function(e) {})
  }
  
  # Adjust p-values and attach compound ID
  temp_result$pfdr <- p.adjust(temp_result$P, method = "BH")
  temp_result_met <- cbind(colnames(dtscaled)[481:ncol(dtscaled)], temp_result, temp_confint, temp_result_iqr)
  colnames(temp_result_met)[1] <- "COMP_ID"

  
  # Store the result in a named list
  result_name <- paste0("dtscaled_", exposure, "_met")
  main_results[[result_name]] <- temp_result_met
  
  # Store summary statistics
  MWASStat1[kk, ] <- c(
    result_name,
    sum(temp_result_met$P < 0.05, na.rm = TRUE),
    sum(temp_result_met$P < 0.01, na.rm = TRUE),
    sum(temp_result_met$P < 0.005, na.rm = TRUE),
    sum(temp_result_met$P < 0.0005, na.rm = TRUE),
    sum(temp_result_met$pfdr < 0.20, na.rm = TRUE),
    sum(temp_result_met$pfdr < 0.05, na.rm = TRUE)
  )
  
  kk <- kk + 1
}

####LC Analysis
for (exposure in exposures) {
  
  # Retrieve first-stage result
  result_name <- paste0("dtscaled_", exposure, "_met")
  res_df <- main_results[[result_name]]
  
  # Filter for significant metabolites
  sig_met <- subset(res_df, pfdr < 0.2 & !is.na(pfdr))
  
  if (nrow(sig_met) == 0) {
    # Skip if no significant metabolites
    next
  }
  
  # Build variable list
  met_names <- sig_met$COMP_ID
  var_list <- c(exposure, "AgeBloodDraw", "SEX", "RACE", "BMI", "EDUCGRP", "MVUSE",
                "FV_UPDATED", "ALC", "Smokegroup1", "PASSIVESMOKER", "CACO.x", met_names)
  
  # Subset the data
  data_subset <- dtscaled[, var_list]
  
  # Prepare result dataframes
  n_met <- length(met_names)
  LC_df <- data.frame(matrix(nrow = n_met, ncol = 4))
  colnames(LC_df) <- c("Est", "Std", "t-value", "P")
  
  LC_confint <- data.frame(matrix(nrow = n_met, ncol = 2))
  colnames(LC_confint) <- c("Lower", "Upper")
  
  # Run linear models
  for (i in 1:n_met) {
    tryCatch({
      formula <- as.formula(
        paste0("data_subset[, i + 12] ~ factor(CACO.x) + BMI + AgeBloodDraw + SEX + RACE + ",
               "factor(EDUCGRP) + factor(MVUSE) + as.numeric(FV_UPDATED) + ",
               "factor(ALC) + factor(Smokegroup1) + factor(PASSIVESMOKER)")
      )
      lmfit <- lm(formula, data = data_subset)
      coef_vals <- summary(lmfit)$coefficients[2, ]
      LC_df[i, ] <- coef_vals
      
      conf_vals <- confint(lmfit)[2, ]
      LC_confint[i, ] <- conf_vals
    }, error = function(e) {})
  }
  
  # Adjust p-values
  LC_df$pfdr <- p.adjust(LC_df$P, method = "BH")
  
  # Combine all results
  LC_met <- cbind(met_names, LC_df, LC_confint)
  colnames(LC_met)[1] <- "COMP_ID"
  LC_met<-merge(LC_met, biochem.blood, by = "COMP_ID")
  
  # Store the final LC result
  main_results[[paste0(exposure, "_LC_met")]] <- LC_met
  
  # Store MWAS summary for LC
  MWASStat1[kk, ] <- c(
    paste0(exposure, "_LC_met"),
    sum(LC_met$P < 0.05, na.rm = TRUE),
    sum(LC_met$P < 0.01, na.rm = TRUE),
    sum(LC_met$P < 0.005, na.rm = TRUE),
    sum(LC_met$P < 0.0005, na.rm = TRUE),
    sum(LC_met$pfdr < 0.20, na.rm = TRUE),
    sum(LC_met$pfdr < 0.05, na.rm = TRUE)
  )
  
  kk <- kk + 1
}

main_sig_LC_results <- lapply(main_results, function(df) {
  subset(df, pfdr < 0.2 & !is.na(pfdr))
})

###pull the AP data
main_filter_id<-list(
  dtscaled_CO_exp_met = main_sig_LC_results[["CO_exp_LC_met"]]$COMP_ID,
  dtscaled_NO2_exp_met = main_sig_LC_results[["NO2_exp_LC_met"]]$COMP_ID,
  dtscaled_PM10_exp_met = main_sig_LC_results[["PM10_exp_LC_met"]]$COMP_ID,
  dtscaled_PM25_exp_met = main_sig_LC_results[["PM25_exp_LC_met"]]$COMP_ID,
  LC = main_sig_LC_results[["CO_exp_LC_met"]]$COMP_ID
)

main_filtered_list <- mapply(function(df, ids) {
  df[df$COMP_ID %in% ids, ]
}, main_results[names(main_filter_id)], main_filter_id, SIMPLIFY = FALSE)

library(openxlsx)
wb<-createWorkbook()
addWorksheet(wb, "CO", tabColour = "black")
addWorksheet(wb, "NO2", tabColour = "black")
addWorksheet(wb, "PM10", tabColour = "black")
addWorksheet(wb, "PM25", tabColour = "black")
writeData(wb, "CO", main_filtered_list[["dtscaled_CO_exp_met"]], rowNames=T, colNames=T)
writeData(wb, "NO2", main_filtered_list[["dtscaled_NO2_exp_met"]], rowNames=T, colNames=T)
writeData(wb, "PM10", main_filtered_list[["dtscaled_PM10_exp_met"]], rowNames=T, colNames=T)
writeData(wb, "PM25", main_filtered_list[["dtscaled_PM25_exp_met"]], rowNames=T, colNames=T)
saveWorkbook(wb, file="main1.xlsx", overwrite=TRUE)
