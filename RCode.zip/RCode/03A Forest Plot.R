library(ggplot2)
library(patchwork)

colors<-c("normal" = "black", "highlight" = "red")

ids<-c(sig_CO_LC$COMP_ID, sig_NO2_LC$COMP_ID, sig_PM10_LC$COMP_ID, sig_PM25_LC$COMP_ID)
ids<-unique(ids)

CO_forest<-main_results[["dtscaled_CO_exp_met"]][main_results[["dtscaled_CO_exp_met"]]$COMP_ID %in% ids,]
CO_forest<-merge(CO_forest, biochem.blood, by = "COMP_ID")
CO_forest$highlight<-c("highlight","highlight","highlight","highlight","highlight","normal","highlight","highlight")

CO_plot<-ggplot(data = CO_forest, aes(x = Est, y = BIOCHEMICAL, color = highlight)) +
  geom_point() +
  geom_errorbarh(aes(xmin = Lower_CI, xmax = Upper_CI, color = highlight), height = 0.25) +
  geom_vline(xintercept = 0, color = "black", linetype = "dashed", alpha = 1) +
  scale_color_manual(values = colors)+
  labs(title = "CO",
       y = "Metabolite")+
  theme(
    legend.position = "none",
    axis.title.x = element_text(size = 10),
    axis.title.y = element_text(size = 16, face = "bold"),
    axis.text.y = element_text(size = 13),
    axis.text.x = element_text(size = 7))

NO2_forest<-main_results[["dtscaled_NO2_exp_met"]][main_results[["dtscaled_NO2_exp_met"]]$COMP_ID %in% ids,]
NO2_forest<-merge(NO2_forest, biochem.blood, by = "COMP_ID")
NO2_forest$highlight<-c("highlight","highlight","highlight","highlight","highlight","normal","highlight","highlight")

NO2_plot<-ggplot(NO2_forest, aes(x = Est, y = BIOCHEMICAL, color = highlight)) +
  geom_point() +
  geom_errorbarh(aes(xmin = Lower_CI, xmax = Upper_CI, color = highlight), height = 0.25) +
  geom_vline(xintercept = 0, color = "black", linetype = "dashed", alpha = 1) +
  scale_color_manual(values = colors)+
  labs(title =  expression("NO"[2]))+
  theme(
    legend.position = "none",                      # Remove the legend
    axis.title.y = element_blank(),                # Remove y-axis title
    axis.text.y = element_blank(),                 # Remove y-axis text
    axis.ticks.y = element_blank(),                 # Remove y-axis ticks
    axis.title.x = element_text(size = 10),
    axis.text.x = element_text(size = 7)
  )

O3_forest<-main_results[["dtscaled_O3_exp_met"]][main_results[["dtscaled_O3_exp_met"]]$COMP_ID %in% ids,]
O3_forest<-merge(O3_forest, biochem.blood, by = "COMP_ID")
O3_forest$highlight<-c("normal","normal","normal","normal","normal","normal","normal","normal")

O3_plot<-ggplot(O3_forest, aes(x = Est, y = BIOCHEMICAL, color = highlight)) +
  geom_point() +
  geom_errorbarh(aes(xmin = Lower_CI, xmax = Upper_CI, color = highlight), height = 0.25) +
  geom_vline(xintercept = 0, color = "black", linetype = "dashed", alpha = 1) +
  scale_color_manual(values = colors)+
  labs(title =  expression("O"[3]))+
  theme(
    legend.position = "none",                      # Remove the legend
    axis.title.y = element_blank(),                # Remove y-axis title
    axis.text.y = element_blank(),                 # Remove y-axis text
    axis.ticks.y = element_blank(),                # Remove y-axis ticks
    axis.title.x = element_text(size = 10),
    axis.text.x = element_text(size = 7)
  )


PM10_forest<-main_results[["dtscaled_PM10_exp_met"]][main_results[["dtscaled_PM10_exp_met"]]$COMP_ID %in% ids,]
PM10_forest<-merge(PM10_forest, biochem.blood, by = "COMP_ID")
PM10_forest$highlight<-c("highlight","highlight","normal","highlight","highlight","normal","normal","highlight")

PM10_plot<-ggplot(PM10_forest, aes(x = Est, y = BIOCHEMICAL, color = highlight)) +
  geom_point() +
  geom_errorbarh(aes(xmin = Lower_CI, xmax = Upper_CI, color = highlight), height = 0.25) +
  geom_vline(xintercept = 0, color = "black", linetype = "dashed", alpha = 1) +
  scale_color_manual(values = colors)+
  labs(title = expression("PM"[10]))+
  labs(color = "Legend")+
  scale_color_manual(
    values = c("highlight" = "red", "normal" = "black"),
    labels = c("highlight" = "Significant", "normal" = "Not Significant")
  )+
  theme(
    legend.position = "bottom",                      
    axis.title.y = element_blank(),                # Remove y-axis title
    axis.text.y = element_blank(),                 # Remove y-axis text
    axis.ticks.y = element_blank(),                 # Remove y-axis ticks
    axis.title.x = element_text(size = 10),
    axis.text.x = element_text(size = 7)
  )


PM25_forest<-main_results[["dtscaled_PM25_exp_met"]][main_results[["dtscaled_PM25_exp_met"]]$COMP_ID %in% ids,]
PM25_forest<-merge(PM25_forest, biochem.blood, by = "COMP_ID")
PM25_forest$highlight<-c("highlight","highlight","normal","highlight","highlight","highlight","highlight","highlight")

PM25_plot<-ggplot(PM25_forest, aes(x = Est, y = BIOCHEMICAL, color = highlight)) +
  geom_point() +
  geom_errorbarh(aes(xmin = Lower_CI, xmax = Upper_CI, color = highlight), height = 0.25) +
  geom_vline(xintercept = 0, color = "black", linetype = "dashed", alpha = 1) +
  scale_color_manual(values = colors)+
  labs(title =  expression("PM"[2.5]))+
  theme(
    legend.position = "none",                      # Remove the legend
    axis.title.y = element_blank(),                # Remove y-axis title
    axis.text.y = element_blank(),                 # Remove y-axis text
    axis.ticks.y = element_blank(),                 # Remove y-axis ticks
    axis.title.x = element_text(size = 10),
    axis.text.x = element_text(size = 7)
  )


SO2_forest<-main_results[["dtscaled_SO2_exp_met"]][main_results[["dtscaled_SO2_exp_met"]]$COMP_ID %in% ids,]
SO2_forest<-merge(SO2_forest, biochem.blood, by = "COMP_ID")
SO2_forest$highlight<-c("normal","normal","normal","normal","normal","normal","normal","normal")

SO2_plot<-ggplot(SO2_forest, aes(x = Est, y = BIOCHEMICAL, color = highlight)) +
  geom_point() +
  geom_errorbarh(aes(xmin = Lower_CI, xmax = Upper_CI, color = highlight), height = 0.25) +
  geom_vline(xintercept = 0, color = "black", linetype = "dashed", alpha = 1) +
  scale_color_manual(values = colors)+
  labs(title = expression("SO"[2]))+
  theme(
    legend.position = "none",                      # Remove the legend
    axis.title.y = element_blank(),                # Remove y-axis title
    axis.text.y = element_blank(),                 # Remove y-axis text
    axis.ticks.y = element_blank(),                 # Remove y-axis ticks
    axis.title.x = element_text(size = 10),
    axis.text.x = element_text(size = 7)
  )


#####LUNG CANCER
LC_data<-main_sig_LC_results[["CO_exp_LC_met"]]
unknown<-main_sig_LC_results[["PM25_exp_LC_met"]][5,]
LC_data<-merge(LC_data, unknown, all = TRUE)

LC_forest<-LC_data[LC_data$COMP_ID %in% ids,]
LC_forest$highlight<-c("highlight","highlight","highlight","highlight","highlight","highlight","highlight","highlight")

LC_plot<-ggplot(LC_forest, aes(x = Est, y = BIOCHEMICAL, color = highlight)) +
  geom_point() +
  geom_errorbarh(aes(xmin = Lower, xmax = Upper, color = highlight), height = 0.25) +
  geom_vline(xintercept = 0, color = "black", linetype = "dashed", alpha = 1) +
  scale_color_manual(values = colors)+
  labs(title = "Lung Cancer")+
  theme(
    legend.position = "none",                      # Remove the legend
    axis.title.y = element_blank(),                # Remove y-axis title
    axis.text.y = element_blank(),                 # Remove y-axis text
    axis.ticks.y = element_blank(),                 # Remove y-axis ticks
    axis.title.x = element_text(size = 10),
    axis.text.x = element_text(size = 7)
  )

CO_plot + NO2_plot + O3_plot + PM10_plot + PM25_plot + SO2_plot + LC_plot + plot_layout(ncol = 7)
