library(ggplot2)
library(magrittr)
library(dplyr)
library(metan)
library(ggsankey)

sankey_data<-read.csv("sankey.csv")

path_order <- sankey_data %>%
  arrange(expos, Metabolites)
path_order <- unique(path_order$Metabolites)

sankey_data <- sankey_data %>% 
  dplyr::select(Exposure, Metabolites, Outcome) %>%
  make_long(Exposure, Metabolites, Outcome)
sankey_data<-factor(sankey_data$node, levels = c(1:8, path_order))


tiff(fs::path("C:/Users/schow4/Desktop", "Figure 3.tif"), res = 300, width = 750, height = 350)
ggplot(sankey_data, aes(x = x,
                    next_x = next_x, 
                    node = node, 
                    next_node = next_node,
                    fill = factor(node))) +
  geom_sankey() +
  theme(legend.position = "none",                      # Remove the legend
        axis.title.y = element_blank(),                # Remove y-axis title
        axis.text.y = element_blank(),                 # Remove y-axis text
        axis.ticks.y = element_blank(),                 # Remove y-axis ticks
        axis.title.x = element_blank(),
        axis.text.x = element_blank())
  scale_fill_discrete(drop = FALSE)
dev.off()

+
  theme(
    legend.position = "none",                      # Remove the legend
    axis.title.y = element_blank(),                # Remove y-axis title
    axis.text.y = element_blank(),                 # Remove y-axis text
    axis.ticks.y = element_blank(),                 # Remove y-axis ticks
    axis.title.x = element_text(size = 10),
    axis.text.x = element_text(size = 7)
  )

